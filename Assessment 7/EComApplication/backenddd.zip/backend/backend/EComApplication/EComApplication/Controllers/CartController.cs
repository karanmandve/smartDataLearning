﻿using core.App.Cart.Command;
using domain.ModelDto;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace EComApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartController : ControllerBase
    {
        private readonly IMediator _mediator;
        public CartController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpPost("add-to-cart")]
        public async Task<IActionResult> AddToCart(AddToCartDto model)
        {
            var command = new AddToCartCommand
            {
                AddToCartData = model
            };

            var result = await _mediator.Send(command);
            if (!result)
            {
                return Conflict(new
                {
                    statusCode = 409,
                    message = "Product already exist in cart"
                });
            }
            return Ok(new
            {
                statusCode = 200,
                message = "Product added to cart successfully"
            });
        }
    }
}
