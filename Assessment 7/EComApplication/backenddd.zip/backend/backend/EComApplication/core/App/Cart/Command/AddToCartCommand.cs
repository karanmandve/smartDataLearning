﻿using core.Interface;
using Mapster;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace core.App.Cart.Command
{
    public class AddToCartCommand : IRequest<bool>
    {
        public domain.ModelDto.AddToCartDto AddToCartData { get; set; }
    }
    public class AddToCartCommandHandler : IRequestHandler<AddToCartCommand, bool>
    {
        private readonly IAppDbContext _context;
        public AddToCartCommandHandler(IAppDbContext context)
        {
            _context = context;
        }
        public async Task<bool> Handle(AddToCartCommand request, CancellationToken cancellationToken)
        {

            var addToCartData = request.AddToCartData;

            var cartMasterData = await _context.Set<domain.Model.Cart.CartMaster>()
                .FirstOrDefaultAsync(cart => cart.UserId == addToCartData.UserId);

            if (cartMasterData == null)
            {
                cartMasterData = new domain.Model.Cart.CartMaster
                {
                    UserId = addToCartData.UserId
                };

                await _context.Set<domain.Model.Cart.CartMaster>().AddAsync(cartMasterData);
                await _context.SaveChangesAsync(cancellationToken);
            }

            var product = await _context.Set<domain.Model.Products.Product>()
                .FirstOrDefaultAsync(p => p.Id == addToCartData.ProductId);

            if (product == null)
            {
                return false;
            }

            if (product.Stock < addToCartData.Qty)
            {
                return false;
            }

            var existingCartDetail = await _context.Set<domain.Model.Cart.CartDetail>()
                .FirstOrDefaultAsync(cd => cd.CartId == cartMasterData.Id && cd.ProductId == addToCartData.ProductId);

            if (existingCartDetail != null)
            {
                existingCartDetail.Qty += addToCartData.Qty;
            }
            else
            {
                var cartDetail = new domain.Model.Cart.CartDetail
                {
                    CartId = cartMasterData.Id,
                    ProductId = addToCartData.ProductId,
                    Qty = addToCartData.Qty
                };
                await _context.Set<domain.Model.Cart.CartDetail>().AddAsync(cartDetail);
            }

            product.Stock -= addToCartData.Qty;

            await _context.SaveChangesAsync(cancellationToken);

            return true;
        }
    }
}
