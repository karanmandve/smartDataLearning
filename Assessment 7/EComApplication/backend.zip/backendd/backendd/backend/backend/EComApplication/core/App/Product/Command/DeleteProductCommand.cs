﻿using core.Interface;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace core.App.Product.Command
{
    public class DeleteProductCommand : IRequest<bool>
    {
        public int ProductId { get; set; }
    }

    public class DeleteProductCommandHandler : IRequestHandler<DeleteProductCommand, bool>
    {
        private readonly IAppDbContext _context;
        public DeleteProductCommandHandler(IAppDbContext context)
        {
            _context = context;
        }
        public async Task<bool> Handle(DeleteProductCommand request, CancellationToken cancellationToken)
        {
            var product = await _context.Set<domain.Model.Products.Product>().FindAsync(request.ProductId);
            if (product == null)
            {
                return false;
            }
            
            product.IsDeleted = true;

            await _context.SaveChangesAsync(cancellationToken);
            return true;
        }
    }
}
