﻿using core.Interface;
using Mapster;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace core.App.Cart.Command
{
    public class AddToCartCommand : IRequest<bool>
    {
        public domain.ModelDto.AddToCartDto AddToCartData { get; set; }
    }

    public class AddToCartCommandHandler : IRequestHandler<AddToCartCommand, bool>
    {
        private readonly IAppDbContext _context;
        private static readonly SemaphoreSlim _semaphore = new SemaphoreSlim(1, 1);

        public AddToCartCommandHandler(IAppDbContext context)
        {
            _context = context;
        }

        public async Task<bool> Handle(AddToCartCommand request, CancellationToken cancellationToken)
        {
            await _semaphore.WaitAsync(cancellationToken);
            try
            {
                var addToCartData = request.AddToCartData;

                // Fetch CartMaster
                var cartMasterData = await _context.Set<domain.Model.Cart.CartMaster>()
                    .AsNoTracking()
                    .FirstOrDefaultAsync(cart => cart.UserId == addToCartData.UserId, cancellationToken);

                if (cartMasterData == null)
                {
                    cartMasterData = new domain.Model.Cart.CartMaster
                    {
                        UserId = addToCartData.UserId
                    };

                    await _context.Set<domain.Model.Cart.CartMaster>().AddAsync(cartMasterData, cancellationToken);
                    await _context.SaveChangesAsync(cancellationToken);
                }

                // Fetch Product
                var product = await _context.Set<domain.Model.Products.Product>()
                    .FirstOrDefaultAsync(p => p.Id == addToCartData.ProductId, cancellationToken);

                if (product == null || product.Stock < addToCartData.Quantity)
                {
                    return false;
                }

                // Fetch existing CartDetail
                var existingCartDetail = await _context.Set<domain.Model.Cart.CartDetail>()
                    .FirstOrDefaultAsync(cd => cd.CartId == cartMasterData.Id && cd.ProductId == addToCartData.ProductId, cancellationToken);

                if (existingCartDetail != null)
                {
                    existingCartDetail.Quantity += addToCartData.Quantity;
                    _context.Set<domain.Model.Cart.CartDetail>().Update(existingCartDetail);
                }
                else
                {
                    var cartDetail = new domain.Model.Cart.CartDetail
                    {
                        CartId = cartMasterData.Id,
                        ProductId = addToCartData.ProductId,
                        Quantity = addToCartData.Quantity
                    };
                    await _context.Set<domain.Model.Cart.CartDetail>().AddAsync(cartDetail, cancellationToken);
                }

                // Update product stock
                product.Stock -= addToCartData.Quantity;
                _context.Set<domain.Model.Products.Product>().Update(product);

                await _context.SaveChangesAsync(cancellationToken);

                return true;
            }
            finally
            {
                _semaphore.Release();
            }
        }
    }
}
