﻿using core.Interface;
using Dapper;
using MediatR;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace core.App.Cart.Query
{
    public class CartCountQuery : IRequest<int>
    {
        public int UserId { get; set; }
    }

    public class CartCountQueryHandler : IRequestHandler<CartCountQuery, int>
    {
        private readonly IAppDbContext _appDbContext;

        public CartCountQueryHandler(IAppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public async Task<int> Handle(CartCountQuery request, CancellationToken cancellationToken)
        {

            using var connection = _appDbContext.GetConnection();
            var query = @"
                        SELECT COUNT(DISTINCT cd.ProductId) AS ProductCount
                        FROM CartMasters cm
                        JOIN CartDetails cd ON cm.Id = cd.CartId
                        WHERE cm.UserId = @UserId";

            var result = await connection.ExecuteScalarAsync<int>(query, new { UserId = request.UserId });
            return result;
        }
    }
}
