﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace domain.ModelDto
{
    public class FakeCheckoutDto
    {
        public int UserId { get; set; }
        public string CardNumber { get; set; }
        public string ExpiryDate { get; set; }
        public string CVV { get; set; }
        public string DeliveryAddress { get; set; }
        public int DeliveryZipcode { get; set; }
        public int DeliveryStateId { get; set; }
        public int DeliveryCountryId { get; set; }
    }
}
