﻿using core.App.Cart.Command;
using core.App.Cart.Query;
using domain.Model.Cards;
using domain.ModelDto;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EComApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartController : ControllerBase
    {
        private readonly IMediator _mediator;
        public CartController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpPost("add-to-cart")]
        public async Task<IActionResult> AddToCart(AddToCartDto model)
        {
            var command = new AddToCartCommand
            {
                AddToCartData = model
            };

            var result = await _mediator.Send(command);
            if (!result)
            {
                return Conflict(new
                {
                    statusCode = 409,
                    message = "Product already exist in cart"
                });
            }
            return Ok(new
            {
                statusCode = 200,
                message = "Product added to cart successfully"
            });
        }

        [HttpGet("get-cart-products/{userId}")]
        public async Task<IActionResult> GetCartProducts(int userId)
        {
            var query = new GetCartProductByUserIdQuery { UserId = userId };
            var products = await _mediator.Send(query);
            return Ok(products);
        }

        [HttpPut("update-cart-quantity")]
        public async Task<IActionResult> UpdateCartQuantity(domain.ModelDto.CartQuantityChangeDto quantityChangeData)
        {
            if (quantityChangeData == null || (quantityChangeData.QuantityChange != 1 && quantityChangeData.QuantityChange != -1))
            {
                return BadRequest("Invalid quantity change.");
            }

            var command = new UpdateCartQuantityCommand
            {
                QuantityChangeData = quantityChangeData
            };

            var result = await _mediator.Send(command);

            if (result)
            {
                return Ok(new
                {
                    statusCode = 200,
                    message = "Cart Quantity Updated Successfully"
                });
            }
            else
            {
                return BadRequest(new
                {
                    statusCode = 400,
                    message = "Cart Not Updated Successfully"
                });
            }
        }

        [HttpGet("get-cart-count/{userId}")]
        public async Task<IActionResult> GetCartCount(int userId)
        {
            var cartCount = await _mediator.Send(new CartCountQuery { UserId = userId });
            return Ok(cartCount);
        }

        [HttpDelete("remove-product-from-cart/{productId}/{userId}")]
        public async Task<IActionResult> RemoveProductById(int productId, int userId)
        {
            var result = await _mediator.Send(new RemoveProductById { ProductId = productId, UserId = userId });

            if (result == false)
            {
                return NotFound(new
                {
                    statusCode = 404,
                    message = "Product not found"
                });
            }

            return Ok(new
            {
                statusCode = 200,
                message = "Product Removed Successfully"
            });
        }


        [HttpPost("fake-pay")]
        public async Task<IActionResult> FakeCheckout(domain.ModelDto.FakeCheckoutDto checkoutRequest)
        {
            if (checkoutRequest == null)
                return BadRequest("Invalid request payload.");

            var command = new FakeCheckoutCommand
            {
                CheckoutData = checkoutRequest
            };

            var response = await _mediator.Send(command);

            if (response.Success)
                return Ok(response);

            return BadRequest(response);
        }



        [HttpPost("pay")]
        public async Task<IActionResult> Checkout(domain.ModelDto.CheckoutDto checkoutRequest)
        {
            if (checkoutRequest == null)
                return BadRequest("Invalid request payload.");

            var command = new CheckoutCommand
            {
                CheckoutData = checkoutRequest
            };

            var response = await _mediator.Send(command);

            if (response.Success)
                return Ok(response);

            return BadRequest(response);
        }




    }
}
