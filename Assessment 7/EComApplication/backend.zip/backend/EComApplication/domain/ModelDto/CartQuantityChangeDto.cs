﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace domain.ModelDto
{
    public class CartQuantityChangeDto
    {
        public int UserId { get; set; }
        public int ProductId { get; set; }
        public int QuantityChange { get; set; }
    }
}
