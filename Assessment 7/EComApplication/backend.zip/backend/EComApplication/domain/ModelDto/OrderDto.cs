﻿using domain.Model.Products;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace domain.ModelDto
{
    public class OrderDto
    {
        public string InvoiceId { get; set; }
        public DateTime InvoiceDate { get; set; }
        public float Subtotal { get; set; }
        public string DeliveryAddress { get; set; }
        public string DeliveryState { get; set; }
        public string DeliveryCountry { get; set; }
        public string InvoicePdfLink { get; set; }
    }
}
