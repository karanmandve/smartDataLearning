﻿using core.Interface;
using domain.Model;
using domain.Model.Otp;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace core.App.User.Command
{
    public class SendOtpCommand : IRequest<object>
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }

    //public class UserLoginQuery : IRequest<Object>
    //{
    //    public domain.ModelDto.LoginDto LoginUser { get; set; }
    //    public string Otp { get; set; } // Add OTP property
    //}

    public class SendOtpQueryHandler : IRequestHandler<SendOtpCommand, object>
    {
        private readonly IAppDbContext _context;
        private readonly IConfiguration _configuration;
        private readonly IEmailService _emailService; // Add email service

        public SendOtpQueryHandler(IAppDbContext context, IConfiguration configuration, IEmailService emailService)
        {
            _context = context;
            _configuration = configuration;
            _emailService = emailService;
        }

        public async Task<object> Handle(SendOtpCommand request, CancellationToken cancellationToken)
        {
            var username = request.Username;
            var password = request.Password;

            var existingUser = await _context.Set<domain.Model.Users.User>().FirstOrDefaultAsync(x => x.Username == username);

            if (existingUser == null || !BCrypt.Net.BCrypt.Verify(password, existingUser.Password))
            {
                return "Email or Password Invalid";
            }


            var otp = new Random().Next(100000, 999999).ToString();

            await _context.Set<Otp>().AddAsync(new domain.Model.Otp.Otp { Username = existingUser.Username, Code = otp, Expiration = DateTime.Now.AddMinutes(5) });
            await _context.SaveChangesAsync();

            // Send OTP to user's email
            await _emailService.SendEmailAsync(
                existingUser.Email, // recipient's email
                "Your OTP Code", // email subject
                $"<html><body style='font-family: Arial, sans-serif;'>" +
                $"  <table width='100%' cellpadding='0' cellspacing='0' style='background-color: #f4f4f4; padding: 20px;'>" +
                $"    <tr>" +
                $"      <td align='center' style='background-color: #2E3B4E; padding: 20px; color: white; font-size: 24px; font-weight: bold;'>" +
                $"        <h1 style='margin: 0; color: white;'>Your OTP Code</h1>" + // OTP title
                $"      </td>" +
                $"    </tr>" +
                $"    <tr>" +
                $"      <td style='background-color: white; padding: 40px; border-radius: 8px; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);'>" +
                $"        <p style='font-size: 18px;'>Dear {existingUser.FirstName},</p>" +
                $"        <p style='font-size: 16px;'>Thank you for using our service. Please find your OTP code below:</p>" +
                $"        <p style='font-size: 24px; font-weight: bold; color: #2E3B4E;'>Your OTP code is: <strong>{otp}</strong></p>" +
                $"        <p style='font-size: 16px;'>Please use the code to verify your account. The OTP is valid for 5 minutes.</p>" +
                $"        <p style='font-size: 16px;'>If you did not request this, please ignore this email or contact our support team.</p>" +
                $"        <p style='font-size: 16px;'>Thank you for choosing our service!</p>" +
                $"      </td>" +
                $"    </tr>" +
                $"    <tr>" +
                $"      <td align='center' style='background-color: #2E3B4E; padding: 20px; color: white; font-size: 14px;'>" +
                $"        <p>© {DateTime.Now.Year} YourCompany. All rights reserved.</p>" + // Dynamically using the current year
                $"      </td>" +
                $"    </tr>" +
                $"  </table>" +
                $"</body></html>"
            );


            return new { Message = "OTP sent to your email" };
        }
    }
}
