﻿using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using core.Interface;
using Mapster;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Internal;
using Microsoft.Extensions.Configuration;
using PasswordGenerator;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace core.App.User.Command
{
    public class CreateUserCommand : IRequest<bool>
    {
        public domain.ModelDto.RegisterDto RegisterUser { get; set; }
        public Stream FileStream { get; set; }
        public string FileName { get; set; }
    }

    public class CreateUserCommandHandler : IRequestHandler<CreateUserCommand, bool>
    {
        private readonly IAppDbContext _context;
        private readonly string _connectionString;
        private readonly string _containerName = "ecomapplication";
        private readonly string _folderName = "profile-images";
        private readonly IEmailService _emailService;

        public CreateUserCommandHandler(IAppDbContext context, IConfiguration configuration, IEmailService emailService)
        {
            _context = context;
            _connectionString = configuration.GetConnectionString("AzureBlobStorage");
            _emailService = emailService;
        }

        public async Task<bool> Handle(CreateUserCommand request, CancellationToken cancellationToken)
        {
            var registerUser = request.RegisterUser;

            var userAlreadyExist = await _context.Set<domain.Model.Users.User>().FirstOrDefaultAsync(us => us.Email == registerUser.Email);

            if (userAlreadyExist != null)
            {
                return false;
            }

            // STORING IMAGES
            var blobServiceClient = new BlobServiceClient(_connectionString);
            var blobContainerClient = blobServiceClient.GetBlobContainerClient(_containerName);
            var blobClient = blobContainerClient.GetBlobClient($"{_folderName}/{Guid.NewGuid()}");

            var blobHttpHeaders = new BlobHttpHeaders
            {
                ContentType = GetContentType(request.FileName) // Get MIME type dynamically
            };

            await blobClient.UploadAsync(request.FileStream, new BlobUploadOptions
            {
                HttpHeaders = blobHttpHeaders
            });

            var imageUrl = blobClient.Uri.ToString();


            // Generate Username
            string formattedDOB = registerUser.DOB.ToString("ddMMyy");
            string username = $"EC_{registerUser.LastName.ToUpper()}{registerUser.FirstName.ToUpper()[0]}{formattedDOB}";

            var existingUsername = await _context.Set<domain.Model.Users.User>().FirstOrDefaultAsync(x => x.Username == username);


            if (existingUsername != null)
            {
                username = $"{existingUsername}1";
            }

            // Generate Password
            var passwordGenerator = new Password(true, true, true, true, 13);
            string password = passwordGenerator.Next();
            password = password.Replace("\\", "");
            var hashPassword = BCrypt.Net.BCrypt.HashPassword(password, 13);
            //const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            //string password = new string(Enumerable.Repeat(chars, 8).Select(s => s[new Random().Next(s.Length)]).ToArray());


            var user = registerUser.Adapt<domain.Model.Users.User>();

            user.Username = username;
            user.Password = hashPassword;
            user.ProfileImageUrl = imageUrl;
            user.IsDeleted = false;
            user.DateCreated = DateTime.Now;

            await _context.Set<domain.Model.Users.User>().AddAsync(user);
            await _context.SaveChangesAsync(cancellationToken);

            await _emailService.SendEmailAsync(
                registerUser.Email,
                "Welcome to EComApplication",
                $"<html><body style='font-family: Arial, sans-serif;'>" +
                $"<table width='100%' cellpadding='0' cellspacing='0' style='background-color: #f4f4f4; padding: 20px;'>" +
                $"  <tr>" +
                $"    <td align='center' style='background-color: #2E3B4E; padding: 20px; color: white; font-size: 24px; font-weight: bold;'>" +
                $"      <h1 style='margin: 0; color: white;'>EComApplication</h1>" + // Replacing the image with the website name
                $"    </td>" +
                $"  </tr>" +
                $"  <tr>" +
                $"    <td style='background-color: white; padding: 40px; border-radius: 8px; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);'>" +
                $"      <p style='font-size: 18px;'>Dear {registerUser.FirstName},</p>" +
                $"      <p style='font-size: 16px;'>Congratulations! Your account has been successfully created on <strong>EComApplication</strong>. We're excited to have you on board.</p>" +
                $"      <p style='font-size: 16px;'><strong>Below are your account details:</strong></p>" +
                $"      <p style='font-size: 16px;'><strong>Username:</strong> {username}</p>" +
                $"      <p style='font-size: 16px;'><strong>Password:</strong> {password}</p>" +
                $"      <p style='font-size: 16px;'>Please make sure to keep your credentials secure. If you did not create this account, please contact our support team immediately.</p>" +
                $"      <p style='font-size: 16px;'>Thank you for choosing <strong>EComApplication</strong>. We look forward to providing you with a great experience.</p>" +
                $"      <p style='font-size: 16px;'>Best regards,<br>The EComApplication Team</p>" +
                $"    </td>" +
                $"  </tr>" +
                $"  <tr>" +
                $"    <td align='center' style='background-color: #2E3B4E; padding: 20px; color: white; font-size: 14px;'>" +
                $"      <p>© {DateTime.Now.Year} EComApplication. All rights reserved.</p>" +  // Dynamically using current year
                $"    </td>" +
                $"  </tr>" +
                $"</table>" +
                $"</body></html>"
            );

            return true;

        }

        private string GetContentType(string fileName)
        {
            return fileName.EndsWith(".jpg") || fileName.EndsWith(".jpeg") ? "image/jpeg" :
                   fileName.EndsWith(".png") ? "image/png" :
                   "application/octet-stream"; // Default fallback
        }
    }
}
