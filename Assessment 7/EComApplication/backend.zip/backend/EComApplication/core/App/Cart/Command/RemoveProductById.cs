﻿using core.Interface;
using Dapper;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace core.App.Cart.Command
{
    public class RemoveProductById : IRequest<bool>
    {
        public int ProductId { get; set; }
        public int UserId { get; set; }
    }

    public class RemoveProductByIdHandler : IRequestHandler<RemoveProductById, bool>
    {
        private readonly IAppDbContext _appDbContext;

        public RemoveProductByIdHandler(IAppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public async Task<bool> Handle(RemoveProductById request, CancellationToken cancellationToken)
        {
            using var connection = _appDbContext.GetConnection();
            var query = @"
            DELETE cd
            FROM CartDetails cd
            INNER JOIN CartMasters c ON cd.CartId = c.Id
            WHERE c.UserId = @UserId AND cd.ProductId = @ProductId;";

            await connection.QueryAsync(query, new { ProductId = request.ProductId, UserId = request.UserId });
            return true;
        }
    }

}
