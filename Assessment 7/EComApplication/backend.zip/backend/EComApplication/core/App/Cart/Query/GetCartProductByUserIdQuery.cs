﻿using core.Interface;
using Dapper;
using Mapster;
using MediatR;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace core.App.Cart.Query
{
    public class GetCartProductByUserIdQuery : IRequest<List<domain.ModelDto.CartProductDto>>
    {
        public int UserId { get; set; }
    }
    public class GetCartProductByUserIdQueryHandler : IRequestHandler<GetCartProductByUserIdQuery, List<domain.ModelDto.CartProductDto>>
    {
        private readonly IAppDbContext _appDbContext;

        public GetCartProductByUserIdQueryHandler(IAppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public async Task<List<domain.ModelDto.CartProductDto>> Handle(GetCartProductByUserIdQuery request, CancellationToken cancellationToken)
        {
            using var connection = _appDbContext.GetConnection();

            // SQL query to get cart products for the user
            var query = @"
                SELECT 
                    p.Id AS ProductId,
                    p.ProductName,
                    p.ProductImageUrl,
                    p.Category,
                    p.SellingPrice,
                    cd.Quantity
                FROM CartMasters cm
                INNER JOIN CartDetails cd ON cm.Id = cd.CartId
                INNER JOIN Products p ON cd.ProductId = p.Id
                WHERE cm.UserId = @UserId AND p.IsDeleted = 0";

            // Parameters to bind in the query
            var parameters = new { UserId = request.UserId };

            // Execute the query and map the result to the DTO
            var products = await connection.QueryAsync<domain.ModelDto.CartProductDto>(query, parameters);
            return products.ToList();
        }
    }

}
