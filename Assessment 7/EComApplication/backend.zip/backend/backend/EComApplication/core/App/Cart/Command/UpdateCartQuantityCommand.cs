﻿using core.Interface;
using domain.Model.Cart;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace core.App.Cart.Command
{
    public class UpdateCartQuantityCommand : IRequest<bool>
    {
        public domain.ModelDto.CartQuantityChangeDto QuantityChangeData { get; set; }
    }

    public class UpdateCartQuantityCommandHandler : IRequestHandler<UpdateCartQuantityCommand, bool>
    {
        private readonly IAppDbContext _appDbContext;

        public UpdateCartQuantityCommandHandler(IAppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public async Task<bool> Handle(UpdateCartQuantityCommand request, CancellationToken cancellationToken)
        {
            var quantityChange = request.QuantityChangeData;

            // Get the CartDetail for the user and product
            var cartDetail = await _appDbContext.Set<domain.Model.Cart.CartDetail>()
                .FirstOrDefaultAsync(cd => cd.CartMaster.UserId == quantityChange.UserId && cd.ProductId == quantityChange.ProductId);

            if (cartDetail == null)
            {
                return false; // No such product in the user's cart
            }

            // Get the product to update its stock
            var product = await _appDbContext.Set<domain.Model.Products.Product>()
                .FirstOrDefaultAsync(p => p.Id == quantityChange.ProductId);

            if (product == null)
            {
                return false; // Product not found
            }

            // Check if the quantity change is valid
            if (quantityChange.QuantityChange == 1)
            {
                // Increment: Update Cart Detail and Product stock
                cartDetail.Quantity += 1;
                product.Stock -= 1;
            }
            else if (quantityChange.QuantityChange == -1)
            {
                // Decrement: Update Cart Detail and Product stock
                if (cartDetail.Quantity > 1)
                {
                    cartDetail.Quantity -= 1;
                    product.Stock += 1;
                }
                else if (cartDetail.Quantity == 1)
                {
                    // If quantity is 1, remove the item from CartDetail
                    _appDbContext.Set<CartDetail>().Remove(cartDetail);
                    product.Stock += 1; // Restore the stock as the product is removed from the cart
                }
            }
            else
            {
                return false; // Invalid quantity change
            }

            // Save the changes
            await _appDbContext.SaveChangesAsync(cancellationToken);
            return true;
        }
    }
}
