using domain.Model.CountryState;
using domain.Model.Users;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace domain.Model.Sales
{
    public class SalesMaster
    {
        [Key]
        public int Id { get; set; }
        public string InvoiceId { get; set; }
        [ForeignKey("User")]
        public int UserId { get; set; }
        public User User { get; set; }
        public DateTime InvoiceDate { get; set; }
        public float Subtotal { get; set; }
        public string DeliveryAddress { get; set; }
        public int DeliveryZipcode { get; set; }
        [ForeignKey("State")]
        public int DeliveryStateId { get; set; }
        public State State { get; set; }
        [ForeignKey("Country")]
        public int DeliveryCountryId { get; set; }
        public Country Country { get; set; }
    }
}
