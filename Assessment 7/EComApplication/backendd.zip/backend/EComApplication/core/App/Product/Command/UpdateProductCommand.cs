﻿using Azure.Storage.Blobs.Models;
using Azure.Storage.Blobs;
using core.App.User.Command;
using core.Interface;
using MediatR;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vonage;

namespace core.App.Product.Command
{
    public class UpdateProductCommand : IRequest<bool>
    {
        public Stream FileStream { get; set; }
        public string FileName { get; set; }
        public domain.ModelDto.ProductDto Product { get; set; }
    }
    public class UpdateProductCommandHandler : IRequestHandler<UpdateProductCommand, bool>
    {

        private readonly IAppDbContext _context;
        private readonly string _connectionString;
        private readonly string _containerName = "ecomapplication";
        private readonly string _folderName = "profile-images";

        public UpdateProductCommandHandler(IAppDbContext appDbContext, IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("AzureBlobStorage");
            _context = appDbContext;
        }


        public async Task<bool> Handle(UpdateProductCommand request, CancellationToken cancellationToken)
        {
            var id = request.Product.Id;

            var product = await _context.Set<domain.Model.Products.Product>().FindAsync(id);

            if (product == null)
            {
                return false;
            }

            // STORING IMAGES
            var blobServiceClient = new BlobServiceClient(_connectionString);
            var blobContainerClient = blobServiceClient.GetBlobContainerClient(_containerName);
            var blobClient = blobContainerClient.GetBlobClient($"{_folderName}/{Guid.NewGuid()}");

            var blobHttpHeaders = new BlobHttpHeaders
            {
                ContentType = GetContentType(request.FileName) // Get MIME type dynamically
            };

            await blobClient.UploadAsync(request.FileStream, new BlobUploadOptions
            {
                HttpHeaders = blobHttpHeaders
            });

            var imageUrl = blobClient.Uri.ToString();


            product.ProductName = request.Product.ProductName;
            product.ProductCode = request.Product.ProductCode;
            product.ProductImageUrl = imageUrl;
            product.UsedId = request.Product.UsedId;
            product.Category = request.Product.Category;
            product.Brand = request.Product.Brand;
            product.SellingPrice = request.Product.SellingPrice;
            product.PurchasePrice = request.Product.PurchasePrice;
            product.PurchaseDate = request.Product.PurchaseDate;
            product.Stock = request.Product.Stock;

            await _context.SaveChangesAsync(cancellationToken);

            return true;
        }

        private string GetContentType(string fileName)
        {
            return fileName.EndsWith(".jpg") || fileName.EndsWith(".jpeg") ? "image/jpeg" :
                   fileName.EndsWith(".png") ? "image/png" :
                   "application/octet-stream"; // Default fallback
        }
    }
}
