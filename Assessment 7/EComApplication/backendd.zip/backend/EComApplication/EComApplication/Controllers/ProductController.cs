﻿using core.App.Product.Command;
using domain.ModelDto;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace EComApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IMediator _mediator;
        public ProductController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpPost("add-product")]
        public async Task<IActionResult> AddProduct(ProductDto model)
        {

            using (var stream = model.ImageFile.OpenReadStream())
            {
                var command = new AddProductCommand
                {
                    FileStream = stream,
                    FileName = model.ImageFile.FileName,
                    Product = model
                };

                var result = await _mediator.Send(command);
                if (!result)
                {
                    return Conflict(new
                    {
                        statusCode = 409,
                        message = "Product already exist"
                    });
                }
                return Ok(new
                {
                    statusCode = 200,
                    message = "Product Created Successfully"
                });
            }

        }


        [HttpDelete("delete-product/{id}")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            
            var result = await _mediator.Send(new DeleteProductCommand { ProductId = id});
            if (!result)
            {
                return NotFound(new
                {
                    statusCode = 404,
                    message = "Product not found"
                });
            }
            return Ok(new
            {
                statusCode = 200,
                message = "Product Deleted Successfully"
            });
        }

        [HttpPut("update-product")]
        public async Task<IActionResult> UpdateProduct(domain.ModelDto.ProductDto product)
        {
            using (var stream = product.ImageFile.OpenReadStream())
            {
                var command = new UpdateProductCommand
                {
                    FileStream = stream,
                    FileName = product.ImageFile.FileName,
                    Product = product
                };

                var result = await _mediator.Send(command);
                if (!result)
                {
                    return NotFound(new
                    {
                        statusCode = 404,
                        message = "Product Not Found"
                    });
                }
                return Ok(new
                {
                    statusCode = 200,
                    message = "Product Updated Successfully"
                });
            }
        }
    }
}
