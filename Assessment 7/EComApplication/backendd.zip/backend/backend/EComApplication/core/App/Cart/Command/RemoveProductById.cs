﻿using core.Interface;
using Dapper;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace core.App.Cart.Command
{
    public class RemoveProductById : IRequest<bool>
    {
        public int ProductId { get; set; }
        public int UserId { get; set; }
    }

    public class RemoveProductByIdHandler : IRequestHandler<RemoveProductById, bool>
    {
        private readonly IAppDbContext _appDbContext;

        public RemoveProductByIdHandler(IAppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public async Task<bool> Handle(RemoveProductById request, CancellationToken cancellationToken)
        {

            var cartDetailsData = await _appDbContext.Set<domain.Model.Cart.CartMaster>().Include(cm => cm.CartDetails).ThenInclude(cd => cd.Product).FirstOrDefaultAsync(cd => cd.UserId == request.UserId && cd.CartDetails.Any(cd => cd.ProductId == request.ProductId));

            var cartDetail = cartDetailsData.CartDetails.First();
            
            cartDetail.Product.Stock += cartDetail.Quantity;
            _appDbContext.Set<domain.Model.Products.Product>().Update(cartDetail.Product);
            await _appDbContext.SaveChangesAsync();

            using var connection = _appDbContext.GetConnection();
            var query = @"
            DELETE cd
            FROM CartDetails cd
            INNER JOIN CartMasters c ON cd.CartId = c.Id
            WHERE c.UserId = @UserId AND cd.ProductId = @ProductId;";

            await connection.QueryAsync(query, new { ProductId = request.ProductId, UserId = request.UserId });
            return true;
        }
    }

}
