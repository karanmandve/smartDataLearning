﻿using core.App.User.Command;
using core.App.User.Query;
using core.App.Users.Command;
using domain.ModelDto;
using domain.ModelDtoValidators;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Diagnostics;

namespace EComApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IMediator _mediator;
        public UserController(IMediator mediator)
        {
            _mediator = mediator;
        }


        [HttpPost("register")]
        public async Task<IActionResult> RegisterUser(domain.ModelDto.RegisterDto model)
        {
            var validator = new RegisterDtoValidator();
            var isModeltValid = validator.Validate(model);

            if (!isModeltValid.IsValid)
            {
                var errorMessage = isModeltValid.Errors[0].ErrorMessage;
                return BadRequest(new { Errors = isModeltValid.Errors.Select(x => x.ErrorMessage).ToList() });
            }

            using (var stream = model.File.OpenReadStream())
            {
                var command = new CreateUserCommand
                {
                    FileStream = stream,
                    FileName = model.File.FileName,
                    RegisterUser = model
                };

                // Use MediatR to handle the command
                var result = await _mediator.Send(command);

                if (!result)
                {
                    return Conflict(new
                    {
                        statusCode = 409,
                        message = "User already exist"
                    });
                }

                return Ok(new
                {
                    statusCode = 200,
                    message = "User Created Successfully"
                });
            }

        }



        [HttpPost("Login")]
        public async Task<IActionResult> LoginUser([FromBody] LoginDto model)
        {
            var validator = new LoginDtoValidator();
            var isModeltValid = validator.Validate(model);

            if (!isModeltValid.IsValid)
            {
                var errorMessage = isModeltValid.Errors[0].ErrorMessage;
                return BadRequest(new { Errors = isModeltValid.Errors.Select(x => x.ErrorMessage).ToList() });
            }


            var result = await _mediator.Send(new UserLoginQuery { LoginUser = model });
            if (result is string)
            {
                return Unauthorized(new
                {
                    statusCode = 401,
                    message = result
                });
            }

            return Ok(new
            {
                statusCode = 200,
                message = "Login Successfull",
                data = result
            });
        }


        [HttpGet("sendotp/{username}")]
        public async Task<IActionResult> SendOtp(string username)
        {
            var result = await _mediator.Send(new SendOtpCommand { Username = username });
            if (result is string)
            {
                return Unauthorized(new
                {
                    statusCode = 401,
                    message = "Invalid Credentials"
                });
            }
            return Ok(new
            {
                statusCode = 200,
                message = "Otp Send Successfully",
                data = result
            });
        }


        [HttpGet("forget-password/{username}/{otp}")]
        public async Task<IActionResult> ForgetPassword(string username, string otp)
        {
            var result = await _mediator.Send(new ForgetUserPassword { Username = username, Otp = otp });
            if (!result)
            {
                return Unauthorized(new
                {
                    statusCode = 401,
                    message = "Invalid Credentials"
                });
            }
            return Ok(new
            {
                statusCode = 200,
                message = "Otp Send Successfully",
                data = result
            });
        }


        [HttpPost("change-password")]
        public async Task<IActionResult> ChangePassword(ChangePasswordDto model)
        {
            var result = await _mediator.Send(new ChangeUserPassword { changePasswordData = model });
            if (!result)
            {
                return Unauthorized(new
                {
                    statusCode = 401,
                    message = "Invalid Credentials"
                });
            }
            return Ok(new
            {
                statusCode = 200,
                message = "Otp Send Successfully",
                data = result
            });
        }

        [HttpGet("user-details/{username}")]
        public async Task<IActionResult> UserDetails(string username)
        {
            var result = await _mediator.Send(new GetUserByUsernameQuery { Username = username });
            return Ok(result);
        }


        [HttpPut("update-user")]
        public async Task<IActionResult> UpdateUser(domain.ModelDto.UpdateUserDto user)
        {
            if (user.ImageFile == null)
            {
                var command = new UpdateUserCommand
                {
                    FileStream = null,
                    FileName = null,
                    User = user
                };

                var result = await _mediator.Send(command);
                if (result is string)
                {
                    return NotFound(new
                    {
                        statusCode = 404,
                        message = "User Not Found"
                    });
                }
                return Ok(new
                {
                    data = result,
                    statusCode = 200,
                    message = "User Updated Successfully"
                });
            }

            using (var stream = user.ImageFile.OpenReadStream())
            {
                var command = new UpdateUserCommand
                {
                    FileStream = stream,
                    FileName = user.ImageFile.FileName,
                    User = user
                };

                var result = await _mediator.Send(command);
                if (result is string)
                {
                    return NotFound(new
                    {
                        statusCode = 404,
                        message = "User Not Found"
                    });
                }
                return Ok(new
                {
                    data = result,
                    statusCode = 200,
                    message = "User Updated Successfully"
                });
            }
        }




    }
}
