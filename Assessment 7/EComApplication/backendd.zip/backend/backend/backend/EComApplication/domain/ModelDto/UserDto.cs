﻿using domain.Model.CountryState;
using domain.Model.Users;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace domain.ModelDto
{
    public class UserDto
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Username { get; set; }
        public string Mobile { get; set; }
        public DateOnly DOB { get; set; }
        public int UserTypeId { get; set; }
        public string ProfileImageUrl { get; set; }
        public string Address { get; set; }
        public int Zipcode { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime DateCreated { get; set; }
        public int StateId { get; set; }
        public int CountryId { get; set; }
    }
}
