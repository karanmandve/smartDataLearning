﻿using core.Interface;
using Mapster;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace core.App.User.Query
{
    public class GetUserByEmailQuery:IRequest<domain.Model.Users.User>
    {
        public string Email { get; set; }
    }

    public class GetUserByEmailQueryHandler : IRequestHandler<GetUserByEmailQuery, domain.Model.Users.User>
    {
        private readonly IAppDbContext _context;

        public GetUserByEmailQueryHandler(IAppDbContext context)
        {
             _context = context;
        }
        public async Task<domain.Model.Users.User> Handle(GetUserByEmailQuery request, CancellationToken cancellationToken)
        {
            var email = request.Email;
            var user = await _context.Set<domain.Model.Users.User>().FirstOrDefaultAsync(x => x.Email == email);
            var userDetail = user.Adapt<domain.Model.Users.User>();    

            return userDetail;

        }
    }
}
