﻿using System;

namespace App.Core.Models
{
    public class StudentDto
    {
        public int StudentId { get; set; }


        public string FirstName { get; set; }


        public string LastName { get; set; }

        public DateTime DateOfBith { get; set; }

    }
}
