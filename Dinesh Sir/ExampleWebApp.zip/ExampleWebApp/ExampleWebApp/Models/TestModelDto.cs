﻿namespace ExampleWebApp.Models
{
    public class TestModelDto
    {
        public int StudentId { get; set; }
        public string Name { get; set; }
    }
}
