﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using UploadImageDemo.User.Command;

namespace UploadImageDemo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IMediator _mediator;
        public UserController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpPost("upload-profile-image-google")]
        public async Task<IActionResult> UploadProfileImageUsingGoogle(IFormFile file)
        {
            try
            {
                var result = await _mediator.Send(new UploadImageUsingGoogleCommand { File = file, IsProfileImage = true });
                return Ok(new { Url = result });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { Error = ex.Message });
            }
        }

        [HttpPost("upload-profile-image-azure")]
        public async Task<IActionResult> UploadProfileImageUsingAzure(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                return BadRequest("No file uploaded.");
            }

            using (var stream = file.OpenReadStream())
            {
                var command = new UploadImageUsingAzureCommand
                {
                    FileStream = stream,
                    FileName = file.FileName
                };

                // Use MediatR to handle the command
                var result = await _mediator.Send(command);
                return Ok(new { FileUrl = result });
            }
        }
    }
}
