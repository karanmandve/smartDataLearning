﻿using Google.Cloud.Storage.V1;
using MediatR;

namespace UploadImageDemo.User.Command
{
    public class UploadImageUsingGoogleCommand : IRequest<string>
    {
        public IFormFile File { get; set; }
        public bool IsProfileImage { get; set; }
    }

    public class UploadImageCommandHandler : IRequestHandler<UploadImageUsingGoogleCommand, string>
    {
        private readonly IConfiguration _configuration;

        public UploadImageCommandHandler(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public async Task<string> Handle(UploadImageUsingGoogleCommand request, CancellationToken cancellationToken)
        {
            var bucketName = _configuration["GoogleCloud:BucketName"];
            var allowedExtensions = new[] { ".jpg", ".jpeg", ".png", ".gif" };
            var maxSizeInBytes = 5 * 1024 * 1024; // 5MB

            if (request.File == null || request.File.Length == 0)
                throw new ArgumentException("File is required.");

            if (request.File.Length > maxSizeInBytes)
                throw new ArgumentException("File size exceeds the maximum allowed size of 5MB.");

            var extension = Path.GetExtension(request.File.FileName).ToLowerInvariant();
            if (Array.IndexOf(allowedExtensions, extension) < 0)
                throw new ArgumentException("Only image files (JPG, PNG, GIF) are allowed.");

            // Determine folder name
            var folderName = request.IsProfileImage ? "profile-images" : "product-images";
            var objectName = $"{folderName}/{Guid.NewGuid()}{extension}";

            var credentials = Google.Apis.Auth.OAuth2.GoogleCredential.FromFile("./dotnetcoreoauth-442304-1f9a17d6f2d6.json");
            var storageClient = await StorageClient.CreateAsync(credentials);

            using (var stream = request.File.OpenReadStream())
            {
                await storageClient.UploadObjectAsync(
                    bucketName,
                    objectName,
                    request.File.ContentType,
                    stream,
                    cancellationToken: cancellationToken
                );
            }

            return $"https://storage.googleapis.com/{bucketName}/{objectName}";
        }

    }
}