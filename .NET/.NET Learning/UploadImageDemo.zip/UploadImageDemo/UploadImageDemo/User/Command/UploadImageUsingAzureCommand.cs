﻿using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using MediatR;

namespace UploadImageDemo.User.Command
{
    public class UploadImageUsingAzureCommand : IRequest<string>
    {
        public Stream FileStream { get; set; }
        public string FileName { get; set; }
    }

    public class UploadImageUsingAzureCommandHandler : IRequestHandler<UploadImageUsingAzureCommand, string>
    {
        private readonly string _connectionString;
        private readonly string _containerName = "ecomapplication";
        private readonly string _folderName = "profile-images"; 

        public UploadImageUsingAzureCommandHandler(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("AzureBlobStorage");
        }

        public async Task<string> Handle(UploadImageUsingAzureCommand request, CancellationToken cancellationToken)
        {
            if (request.FileStream.Length > 5 * 1024 * 1024)
            {
                throw new InvalidOperationException("File size exceeds 5MB.");
            }

            var blobServiceClient = new BlobServiceClient(_connectionString);
            var blobContainerClient = blobServiceClient.GetBlobContainerClient(_containerName);
            var blobClient = blobContainerClient.GetBlobClient($"{_folderName}/{Guid.NewGuid()}");

            var blobHttpHeaders = new BlobHttpHeaders
            {
                ContentType = GetContentType(request.FileName) // Get MIME type dynamically
            };

            await blobClient.UploadAsync(request.FileStream, new BlobUploadOptions
            {
                HttpHeaders = blobHttpHeaders
            });

            return blobClient.Uri.ToString();
        }
        private string GetContentType(string fileName)
        {
            return fileName.EndsWith(".jpg") || fileName.EndsWith(".jpeg") ? "image/jpeg" :
                   fileName.EndsWith(".png") ? "image/png" :
                   "application/octet-stream"; // Default fallback
        }
    }
}
