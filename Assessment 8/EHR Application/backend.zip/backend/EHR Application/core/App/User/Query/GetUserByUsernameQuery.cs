﻿//using core.Interface;
//using Mapster;
//using MediatR;
//using Microsoft.EntityFrameworkCore;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace core.App.User.Query
//{
//    public class GetUserByUsernameQuery : IRequest<domain.ModelDto.UserDto>
//    {
//        public string Username { get; set; }
//    }

//    public class GetUserByEmailQueryHandler : IRequestHandler<GetUserByUsernameQuery, domain.ModelDto.UserDto>
//    {
//        private readonly IAppDbContext _context;

//        public GetUserByEmailQueryHandler(IAppDbContext context)
//        {
//            _context = context;
//        }
//        public async Task<domain.ModelDto.UserDto> Handle(GetUserByUsernameQuery request, CancellationToken cancellationToken)
//        {
//            var username = request.Username;
//            var user = await _context.Set<domain.Model.User.User>().FirstOrDefaultAsync(x => x.Username == username);
//            var userDetail = user.Adapt<domain.ModelDto.UserDto>();

//            return userDetail;

//        }
//    }
//}
