﻿using core.App.User.Command;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace EHR_Application.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IMediator _mediator;
        public UserController(IMediator mediator)
        {
            _mediator = mediator;
        }


        [HttpPost("register")]
        public async Task<IActionResult> RegisterUser(domain.ModelDto.RegisterDto model)
        {
            //var validator = new RegisterDtoValidator();
            //var isModeltValid = validator.Validate(model);

            //if (!isModeltValid.IsValid)
            //{
            //    var errorMessage = isModeltValid.Errors[0].ErrorMessage;
            //    return BadRequest(new { Errors = isModeltValid.Errors.Select(x => x.ErrorMessage).ToList() });
            //}

            using (var stream = model.File.OpenReadStream())
            {
                var command = new CreateUserCommand
                {
                    FileStream = stream,
                    FileName = model.File.FileName,
                    RegisterUser = model
                };

                // Use MediatR to handle the command
                var result = await _mediator.Send(command);

                if (!result.IsSuccess)
                {
                    return Conflict(result);
                }

                return Ok(result);
            }

        }



        //[HttpPost("Login")]
        //public async Task<IActionResult> LoginUser([FromBody] LoginDto model)
        //{
        //    var validator = new LoginDtoValidator();
        //    var isModeltValid = validator.Validate(model);

        //    if (!isModeltValid.IsValid)
        //    {
        //        var errorMessage = isModeltValid.Errors[0].ErrorMessage;
        //        return BadRequest(new { Errors = isModeltValid.Errors.Select(x => x.ErrorMessage).ToList() });
        //    }


        //    var result = await _mediator.Send(new UserLoginQuery { LoginUser = model });
        //    if (result is string)
        //    {
        //        return Unauthorized(new
        //        {
        //            statusCode = 401,
        //            message = result
        //        });
        //    }

        //    return Ok(new
        //    {
        //        statusCode = 200,
        //        message = "Login Successfull",
        //        data = result
        //    });
        //}
    }
}
