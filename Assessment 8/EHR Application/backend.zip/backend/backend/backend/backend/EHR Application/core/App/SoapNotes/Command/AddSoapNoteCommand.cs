﻿using core.API_Response;
using core.Interface;
using Mapster;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace core.App.SoapNotes.Command
{
    public class AddSoapNoteCommand : IRequest<AppResponse<object>>
    {
        public domain.ModelDto.SoapNote.SoapNoteDto SoapNote { get; set; }
    }

    public class AddSoapNoteCommandHandler : IRequestHandler<AddSoapNoteCommand, AppResponse<object>>
    {
        private readonly IAppDbContext _appDbContext;

        public AddSoapNoteCommandHandler(IAppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public async Task<AppResponse<object>> Handle(AddSoapNoteCommand request, CancellationToken cancellationToken)
        {
            var soapNoteData = request.SoapNote.Adapt<domain.Model.SoapNotes.SoapNote>();

            soapNoteData.DateCreated = DateTime.Now;

            var appointment = await _appDbContext.Set<domain.Model.Appointment.Appointment>().FindAsync(soapNoteData.AppointmentId);

            if (appointment == null)
            {
                return AppResponse.Fail<object>(null, message: "Appointment Not Found", statusCode: HttpStatusCodes.NotFound);
            }

            appointment.AppointmentStatus = domain.Model.Appointment.AppointmentStatusEnum.Completed.ToString();

            await _appDbContext.Set<domain.Model.SoapNotes.SoapNote>().AddAsync(soapNoteData);

            await _appDbContext.SaveChangesAsync();

            return AppResponse.Success<object>(null, message: "Successfully Add Soap Note", statusCode: HttpStatusCodes.OK);
        }
    }
}
