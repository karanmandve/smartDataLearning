﻿using core.API_Response;
using core.Interface;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace core.App.Appointment.Command
{
    public class CanceledAppointmentCommand : IRequest<AppResponse<object>>
    {
        public int AppointmentId { get; set; }
    }
    // what to change the status of the appointment to canceled

    public class CanceledAppointmentCommandHandler : IRequestHandler<CanceledAppointmentCommand, AppResponse<object>>
    {
        private readonly IAppDbContext _appDbContext;
        public CanceledAppointmentCommandHandler(IAppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }
        public async Task<AppResponse<object>> Handle(CanceledAppointmentCommand request, CancellationToken cancellationToken)
        {
            var appointmentData = await _appDbContext.Set<domain.Model.Appointment.Appointment>().FindAsync(request.AppointmentId);
            if (appointmentData == null)
            {
                return AppResponse.Fail<object>(message: "Appointment not found", statusCode: HttpStatusCodes.NotFound);
            }
            appointmentData.AppointmentStatus = domain.Model.Appointment.AppointmentStatusEnum.Cancelled.ToString();
            await _appDbContext.SaveChangesAsync();
            return AppResponse.Success<object>(message: "Successfully Canceled Appointment", statusCode: HttpStatusCodes.OK);
        }
    }
}
