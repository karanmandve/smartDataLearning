﻿//using Azure.Storage.Blobs;
//using Azure.Storage.Blobs.Models;
//using core.Interface;
//using Mapster;
//using MediatR;
//using Microsoft.Extensions.Configuration;

//namespace core.App.Users.Command
//{
//    public class UpdateUserCommand : IRequest<object>
//    {
//        public Stream FileStream { get; set; }
//        public string FileName { get; set; }
//        public domain.ModelDto.UpdateUserDto User { get; set; }
//    }

//    public class UpdateUserCommandHandler : IRequestHandler<UpdateUserCommand, object>
//    {
//        private readonly IAppDbContext _context;
//        private readonly string _connectionString;
//        private readonly string _containerName = "ecomapplication";
//        private readonly string _folderName = "user-images";

//        public UpdateUserCommandHandler(IAppDbContext appDbContext, IConfiguration configuration)
//        {
//            _connectionString = configuration.GetConnectionString("AzureBlobStorage");
//            _context = appDbContext;
//        }

//        public async Task<object> Handle(UpdateUserCommand request, CancellationToken cancellationToken)
//        {
//            var id = request.User.Id;

//            var user = await _context.Set<domain.Model.User.User>().FindAsync(id);

//            if (user == null)
//            {
//                return "User Not Exist";
//            }

//            var imageUrl = string.Empty;

//            if (request.FileName != null)
//            {
//                // STORING IMAGES
//                var blobServiceClient = new BlobServiceClient(_connectionString);
//                var blobContainerClient = blobServiceClient.GetBlobContainerClient(_containerName);
//                var blobClient = blobContainerClient.GetBlobClient($"{_folderName}/{Guid.NewGuid()}");

//                var blobHttpHeaders = new BlobHttpHeaders
//                {
//                    ContentType = GetContentType(request.FileName) // Get MIME type dynamically
//                };

//                await blobClient.UploadAsync(request.FileStream, new BlobUploadOptions
//                {
//                    HttpHeaders = blobHttpHeaders
//                });

//                imageUrl = blobClient.Uri.ToString();
//            }

//            user.FirstName = request.User.FirstName;
//            user.LastName = request.User.LastName;
//            user.Mobile = request.User.Mobile;
//            user.DOB = request.User.DOB;
//            if (!string.IsNullOrEmpty(imageUrl))
//            {
//                user.ProfileImageUrl = imageUrl;
//            }
//            user.Address = request.User.Address;
//            user.Zipcode = request.User.Zipcode;
//            user.StateId = request.User.StateId;
//            user.CountryId = request.User.CountryId;

//            await _context.SaveChangesAsync(cancellationToken);

//            var userData = user.Adapt<domain.ModelDto.UserDto>();
//            return userData;
//        }

//        private string GetContentType(string fileName)
//        {
//            return fileName.EndsWith(".jpg") || fileName.EndsWith(".jpeg") ? "image/jpeg" :
//                   fileName.EndsWith(".png") ? "image/png" :
//                   "application/octet-stream"; // Default fallback
//        }
//    }
//}
