﻿using core.API_Response;
using core.Interface;
using Mapster;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace core.App.Appointment.Command
{
    public class AddAppointmentCommand : IRequest<AppResponse<object>>
    {
        public domain.ModelDto.Appointment.AppointmentDto Appointment { get; set; }
    }

    public class AddAppointmentCommandHandler : IRequestHandler<AddAppointmentCommand, AppResponse<object>>
    {
        private readonly IAppDbContext _appDbContext;
        private readonly IRazorpayService _razorpayService;

        public AddAppointmentCommandHandler(IAppDbContext appDbContext, IRazorpayService razorpayService)
        {
            _appDbContext = appDbContext;
            _razorpayService = razorpayService;
        }

        public async Task<AppResponse<object>> Handle(AddAppointmentCommand request, CancellationToken cancellationToken)
        {
            var paymentData = await _razorpayService.VerifyPaymentAsync(request.Appointment.PaymentId, request.Appointment.OrderId);

            Console.WriteLine(paymentData);

            var appointmentData = request.Appointment.Adapt<domain.Model.Appointment.Appointment>();

            await _appDbContext.Set<domain.Model.Appointment.Appointment>().AddAsync(appointmentData);

            return AppResponse.Success<object>(message: "Successfully Add Appointment", statusCode: HttpStatusCodes.OK);
        }
    }
}
