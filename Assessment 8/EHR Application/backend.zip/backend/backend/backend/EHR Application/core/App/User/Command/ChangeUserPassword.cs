﻿//using core.Interface;
//using domain.ModelDto;
//using MediatR;
//using Microsoft.EntityFrameworkCore;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace core.App.User.Command
//{
//    public class ChangeUserPassword : IRequest<bool>
//    {
//        public ChangePasswordDto changePasswordData { get; set; }
//    }

//    public class ChangeUserPasswordHandler : IRequestHandler<ChangeUserPassword, bool>
//    {
//        private readonly IAppDbContext _context;
//        private readonly IEmailService _emailService;

//        public ChangeUserPasswordHandler(IAppDbContext context, IEmailService emailService)
//        {
//            _context = context;
//            _emailService = emailService;
//        }

//        public async Task<bool> Handle(ChangeUserPassword request, CancellationToken cancellationToken)
//        {
//            var username = request.changePasswordData.Username;
//            var newPassword = request.changePasswordData.NewPassword;

//            var existingUser = await _context.Set<domain.Model.User.User>().FirstOrDefaultAsync(user => user.Username == username);

//            if (existingUser == null)
//            {
//                return false;
//            }

//            existingUser.Password = BCrypt.Net.BCrypt.HashPassword(newPassword);

//            await _context.SaveChangesAsync();

//            return true;
//        }
//    }

//}
