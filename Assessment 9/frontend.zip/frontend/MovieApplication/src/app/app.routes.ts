import { Routes } from '@angular/router';
import { RegisterLoginDashboardComponent } from './components/auth/register-login-dashboard/register-login-dashboard.component';
import { ErrorComponent } from './components/error/error.component';
import { LayoutComponent } from './components/layout/layout.component';
import { AdminComponent } from './components/admin/admin.component';
import { authGuardGuard } from './guards/auth-guard.guard';
import { UserComponent } from './components/user/user.component';

export const routes: Routes = [
    {path:"", redirectTo:"login-register", pathMatch:"full"},
    {path:"login-register", component:RegisterLoginDashboardComponent},
    {path: "", component: LayoutComponent, children : [
        {path: "admin", component: AdminComponent, canActivate : [authGuardGuard]},
        {path: "user", component: UserComponent, canActivate : [authGuardGuard]},
        
    ]},
    {path: "**", component: ErrorComponent}
];
