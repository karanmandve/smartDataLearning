import { Routes } from '@angular/router';
import { RegisterLoginDashboardComponent } from './components/auth/register-login-dashboard/register-login-dashboard.component';
import { ErrorComponent } from './components/error/error.component';

export const routes: Routes = [
    {path:"", redirectTo:"login-register", pathMatch:"full"},
    {path:"login-register", component:RegisterLoginDashboardComponent},
    // {path: "", component: LayoutComponent, children : [
    //     {path: "patient-profile", component: ProfileComponent, canActivate : [authGuardGuard]},
    //     {path: "patient-chat/:providerId", component: ChatComponent, canActivate : [authGuardGuard]},
    //     {path: "provider-chat/:patientId", component: ChatComponent, canActivate : [authGuardGuard]},
    //     {path: "provider-profile", component: ProviderProfileComponent, canActivate : [authGuardGuard]},
    //     {path: "home", component: HomeComponent, canActivate : [authGuardGuard]},
    //     {path: "appointment", component: AppointmentComponent, canActivate : [authGuardGuard]},
    //     {path: "complete-appointment/:appointmentId", component: CompleteAppointmentComponent, canActivate : [authGuardGuard]},
    //     {path: "appointment-history", component: AppointmentHistoryComponent, canActivate : [authGuardGuard]},
    // ]},
    {path: "**", component: ErrorComponent}
];
