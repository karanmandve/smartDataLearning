import { Component, inject } from '@angular/core';
import { FormGroup, FormControl, Validators, ValidationErrors, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { SweetAlertToasterService } from '../../../services/toaster/sweet-alert-toaster.service';
import { UserServiceService } from '../../../services/user/user-service.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
  passwordRgx: RegExp = /^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[!@#$%^&*]).{8,}$/

  toaster = inject(SweetAlertToasterService);
  router = inject(Router);
  userService = inject(UserServiceService);


  ngOnInit() {
    this.sanitizeField('firstName');
    this.sanitizeField('lastName');
    this.sanitizeFieldForEmail("email");
  }


  registerForm = new FormGroup({
    firstName: new FormControl('', [
      Validators.required,
      Validators.minLength(2),
      Validators.maxLength(20),
      Validators.pattern(/^[A-Za-z]+(?: [A-Za-z]+)*\s*$/),
    ]),
    lastName: new FormControl('', [
      Validators.required,
      Validators.minLength(2),
      Validators.maxLength(25),
      Validators.pattern(/^[A-Za-z]+(?: [A-Za-z]+)*\s*$/),
    ]),
    email: new FormControl('', [
      Validators.required,
      Validators.email,
      Validators.maxLength(50),
    ]),
    roleId: new FormControl('', Validators.required),
    password: new FormControl('', [Validators.required, Validators.pattern(this.passwordRgx)]),
  });



  onRegisterSubmit() {
    if (this.registerForm.invalid) {
      this.registerForm.markAllAsTouched();
      this.toaster.error('Please Fill And Correct All The fields');
      return;
    }

    // const formData = new FormData();
    // Object.keys(this.registerForm.controls).forEach((field) => {
    //   const value = this.registerForm.get(field)?.value;
    //   formData.append(field, value);
    // });

    this.userService.addUser(this.registerForm.value).subscribe({
      next: (res: any) => {
        this.registerForm.reset();
        if (res.statusCode == 201) {
          this.toaster.success('User Register Successfully');
          setTimeout(() => {
            window.location.reload();
          }, 1000);

        } else {
          this.toaster.error('User Not Register');
        }
      },
      error: (error: any) => {
        if (error.error.statusCode == 409) {
          this.toaster.error('User Already Exist');
          this.registerForm.reset();
        } else {
          this.toaster.error('Error From Our Side');
          console.log(error);
        }
      },
    });
  }



  onKeyPress(event: KeyboardEvent) {
    const charCode = event.which ? event.which : event.keyCode;

    if (charCode < 48 || charCode > 57) {
      event.preventDefault();
    }
  }






  sanitizeField(fieldName: string): void {
    this.registerForm.get(fieldName)?.valueChanges.subscribe((value) => {
      if (value) {
        
        const sanitizedValue = value
          .replace(/[^A-Za-z\s]/g, '') 
          .replace(/\s{2,}/g, ' '); 
        if (value !== sanitizedValue) {
          this.registerForm.get(fieldName)?.setValue(sanitizedValue, {
            emitEvent: false, 
          });
        }
      }
    });
  }


  sanitizeFieldForEmail(fieldName: string): void {
    this.registerForm.get(fieldName)?.valueChanges.subscribe((value) => {
      if (value) {
        const sanitizedValue = value
          .replace(/[^A-Za-z0-9@._-]/g, '')
          .replace(/\s{2,}/g, '') 
          .trim(); 
        if (value !== sanitizedValue) {
          this.registerForm.get(fieldName)?.setValue(sanitizedValue, {
            emitEvent: false, // Prevent triggering valueChanges again
          });
        }
      }
    });
  }
}
