import { Component, ElementRef, inject, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { UserServiceService } from '../../../services/user/user-service.service';
import { SweetAlertToasterService } from '../../../services/toaster/sweet-alert-toaster.service';
import { LoaderService } from '../../../services/loader/loader.service';
import { LoginComponent } from "../login/login.component";
import { RegisterComponent } from "../register/register.component";
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-register-login-dashboard',
  standalone: true,
  imports: [LoginComponent, RegisterComponent, CommonModule],
  templateUrl: './register-login-dashboard.component.html',
  styleUrl: './register-login-dashboard.component.css'
})
export class RegisterLoginDashboardComponent {
  password: string = '';
  confirmPassword: string = '';
  loginData : any;
  registerData: any;
  otpSent: boolean = false;
  forgetOtpSent: boolean = false;
  passwordRgx: RegExp = /^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[!@#$%^&*]).{8,}$/
  isResendDisabled: boolean = false;  // To control the resend button
  forgetOtpIsResendDisabled: boolean = false;  // To control the resend button
  forgetOtpCountdown: number = 30; // Countdown timer for resend OTP
  countdown: number = 30; // Countdown timer for resend OTP
  resendTimeout: any;
  resendOtpTimeout: any;
  todayDate = new Date().toISOString().split('T')[0];
  pastDate = new Date('1901-01-01').toISOString().split('T')[0];
  fileSizeError = false;
  imagePreview: string | ArrayBuffer | null = null;
  isLogin: boolean = true;
  providerRegistration: boolean = false;
  patientRegistration: boolean = false;
  activeForm: string = 'login';
  allSpecialisations: any[] = [];

  @ViewChild('forgotPasswordModal') forgotPasswordModal!: ElementRef;
  
  userService = inject(UserServiceService)
  router = inject(Router)
  toaster = inject(SweetAlertToasterService)
  loader = inject(LoaderService)

  ngonInit() {
  }



  setActiveForm(form: string): void {
    if (form === 'login') {
      // this.loginForm.reset();
      this.isLogin = true;
      this.patientRegistration = false;
      this.providerRegistration = false;
    }else if (form === 'Register') {
      this.providerRegistration = true;
      this.isLogin = false;
      this.patientRegistration = false;
    }

    this.activeForm = form;

  }
}
