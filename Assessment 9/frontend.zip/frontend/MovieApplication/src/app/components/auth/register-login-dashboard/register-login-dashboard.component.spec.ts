import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisterLoginDashboardComponent } from './register-login-dashboard.component';

describe('RegisterLoginDashboardComponent', () => {
  let component: RegisterLoginDashboardComponent;
  let fixture: ComponentFixture<RegisterLoginDashboardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RegisterLoginDashboardComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RegisterLoginDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
