import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormGroup, FormControl, Validators, ReactiveFormsModule } from '@angular/forms';
import { SweetAlertToasterService } from '../../services/toaster/sweet-alert-toaster.service';
import { MovieServiceService } from '../../services/movie/movie-service.service';
import { UserServiceService } from '../../services/user/user-service.service';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';
declare var bootstrap: any;

@Component({
  selector: 'app-admin',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './admin.component.html',
  styleUrl: './admin.component.css'
})
export class AdminComponent {
  movieForm: any;
  movieUpdateForm: any;
  fileSizeError = false;
  userDetails: any;
  allAdminMovies: any [] = [];
  movieId: any;


  toaster = inject(SweetAlertToasterService);
  movieService = inject(MovieServiceService);
  userService = inject(UserServiceService)
  router = inject(Router)

  ngOnInit(): void {

    this.userService.user$.subscribe({
      next: (res: any) => {
        this.userDetails = res;
        this.getMoviesbyAdminId();
      }
    });

    // Initialize the form with fields and validators
    this.movieForm = new FormGroup({
      id : new FormControl(''),
      movieTitle: new FormControl('', [
        Validators.required,
        Validators.minLength(1),
        Validators.maxLength(100),
      ]),
      releaseYear: new FormControl('', [
        Validators.required,
        Validators.min(1900),
        Validators.max((new Date().getFullYear()) + 5)
      ]),
      moviePosterImage: new FormControl<File | null>(null, Validators.required)
    });

    this.movieUpdateForm = new FormGroup({
      id : new FormControl(),
      movieTitle: new FormControl('', [
        Validators.required,
        Validators.minLength(1),
        Validators.maxLength(100),
      ]),
      releaseYear: new FormControl('', [
        Validators.required,
        Validators.min(1900),
        Validators.max((new Date().getFullYear()) + 5)
      ]),
      moviePosterImage: new FormControl<File | null>(null)
    });
    
  }


  onFileSelected(event: Event) {
    const file = (event.target as HTMLInputElement).files?.[0];
    const maxSize = 5 * 1024 * 1024;
  
    if (file) {
      const validTypes = ['image/jpeg', 'image/jpg', 'image/png'];
      // Validate file type
      if (!validTypes.includes(file.type)) {
        this.movieForm.get('moviePosterImage')?.setErrors({ invalidType: true });
        if (event.target instanceof HTMLInputElement) {
          event.target.value = ''; // Clear invalid input
        }
        // return; // Exit if invalid type
      } else {
        this.movieForm.get('moviePosterImage')?.setErrors(null);
      }
  
      // Validate file size
      if (file.size > maxSize) {
        this.fileSizeError = true;
        if (event.target instanceof HTMLInputElement) {
          event.target.value = ''; // Clear input if size is too large
        }
        return; // Exit if size exceeds limit
      } else {
        this.fileSizeError = false;
      }
  
      // Set the file value in the form
      this.movieForm.patchValue({ moviePosterImage: file });
      this.movieForm.get('moviePosterImage')?.updateValueAndValidity();
  
      // File is valid, read and preview it
      // const reader = new FileReader();
      // reader.onload = () => {
      //   this.imagePreview = reader.result as string; // Set the preview
      // };
      // reader.readAsDataURL(file);
    }
  }

  onFileSelectedMovieUpdate(event: Event) {
    const file = (event.target as HTMLInputElement).files?.[0];
    const maxSize = 5 * 1024 * 1024;
  
    if (file) {
      const validTypes = ['image/jpeg', 'image/jpg', 'image/png'];
      // Validate file type
      if (!validTypes.includes(file.type)) {
        this.movieUpdateForm.get('moviePosterImage')?.setErrors({ invalidType: true });
        if (event.target instanceof HTMLInputElement) {
          event.target.value = ''; // Clear invalid input
        }
        // return; // Exit if invalid type
      } else {
        this.movieUpdateForm.get('moviePosterImage')?.setErrors(null);
      }
  
      // Validate file size
      if (file.size > maxSize) {
        this.fileSizeError = true;
        if (event.target instanceof HTMLInputElement) {
          event.target.value = ''; // Clear input if size is too large
        }
        return; // Exit if size exceeds limit
      } else {
        this.fileSizeError = false;
      }
  
      // Set the file value in the form
      this.movieUpdateForm.patchValue({ moviePosterImage: file });
      this.movieUpdateForm.get('moviePosterImage')?.updateValueAndValidity();
  
    }
  }

 
  openModal() {
    this.movieForm.reset(); // Reset form when modal opens
    const modalElement = document.getElementById('movieModal');
    const modal = new bootstrap.Modal(modalElement); // Bootstrap Modal
    modal.show();
  }

  // Close the modal
  closeModal() {
    this.movieForm.reset();
    const modalElement = document.getElementById('movieModal');
    const modal = new bootstrap.Modal(modalElement);
    modal.hide();
  }


  getMoviesbyAdminId(){
    this.movieService.getMoviesOfAdmin(this.userDetails.id).subscribe({
      next: (res: any) => {
        this.allAdminMovies = res.data;
        console.log(this.allAdminMovies);
      },
      error: (err: any) => {
        console.log(err);
      }
    });
  }



  reloadCurrentRoute() {
    // Navigate to the current route again to trigger a reload
    // const currentUrl = this.router.url;
    // this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
    //   this.router.navigate([currentUrl]);
    // });
    window.location.reload();
  }



  // Form submission handler
  onSubmit() {
    if (this.movieForm.invalid) {
      this.movieForm.markAllAsTouched();
      this.toaster.error('Please Fill And Correct All The fields');
      return;
    }

    const formData = new FormData();
    Object.keys(this.movieForm.controls).forEach((field) => {
      if (field === "id"){
        const value = "1";
        formData.append(field, value);
      }
      else{
          const value = this.movieForm.get(field)?.value;
          formData.append(field, value);    
        }
    });

    formData.append("adminId", this.userDetails.id);

    this.movieService.addMovie(formData).subscribe({
      next: (res: any) => {
        
        if (res.statusCode == 200){
          this.toaster.success('Movie Added Successfully');
          this.getMoviesbyAdminId();
        }else{
          this.toaster.error('Failed to add movie');
        }
        this.closeModal();
        this.reloadCurrentRoute();
      },
      error: (err: any) => {
        if (err.error.statusCode === 409) {
          this.toaster.error(err.error.message);
        } else {
        this.toaster.error('Failed to add movie');
        }
        this.closeModal();
        this.reloadCurrentRoute();
      }
    });  
  }
  

  openMovieEditModal(movie: any) {
    this.movieUpdateForm.patchValue(movie);
    
    const modal = new bootstrap.Modal(document.getElementById('editMovieModal'));
    modal.show();
  }

  closeMovieEditModal() {
    this.movieUpdateForm.reset();
    const modal = new bootstrap.Modal(document.getElementById('editMovieModal'));
    modal.hide();
  }


  editMovie(){
    const formData = new FormData();
    Object.keys(this.movieUpdateForm.controls).forEach((field) => {
        const value = this.movieUpdateForm.get(field)?.value;
        formData.append(field, value);
      }
    );


    this.movieService.updateMovie(formData).subscribe({
      next: (res: any) => {
        if (res.statusCode == 200){
          this.toaster.success('Movie Updated Successfully');
          this.getMoviesbyAdminId();
        }else{
          this.toaster.error('Failed to update movie');
        }
        this.reloadCurrentRoute();
        this.closeMovieEditModal();
      },
      error: (err: any) => {
        if (err.error.statusCode === 404) {
          this.toaster.error(err.error.message);
        }else{
          this.toaster.error('Failed to update movie');
        }
        this.reloadCurrentRoute();
        this.closeMovieEditModal();
      }
    });



  }

  deleteMovie(movieId: number){
    
    Swal.fire({
      title: 'Are you sure?',
      text: "You want to delete this movie?",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes',
      cancelButtonText: 'No',
      reverseButtons: true // Optional, swaps the positions of the buttons
    }).then((result: any) => {
      if (result.isConfirmed) {


        this.movieService.deleteMovie(movieId).subscribe({
          next: (res: any) => {
            if (res.statusCode == 200){
              this.toaster.success('Movie Deleted Successfully');
              this.getMoviesbyAdminId();
            }else{
              this.toaster.error('Failed to delete movie');
            }
          },
          error: (err: any) => {
            if (err.error.statusCode === 404) {
              this.toaster.error(err.error.message);
            }else{
              this.toaster.error('Failed to delete movie');
            }
            
          }
        });


      }
    });

  }
}
