import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { UserServiceService } from '../../services/user/user-service.service';
import { MovieServiceService } from '../../services/movie/movie-service.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-user',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './user.component.html',
  styleUrl: './user.component.css'
})
export class UserComponent {

  userDetails: any;
  allMovies: any[] = [];
  filteredMovies: any[] = [];  // To store the filtered movies
  searchQuery: string = '';  // To store the search query

  userService = inject(UserServiceService);
  movieService = inject(MovieServiceService);

  ngOnInit(): void {
    this.getAllMovies();
    this.userService.user$.subscribe({
      next: (res: any) => {
        this.userDetails = res;
      }
    });
  }

  // Fetch all movies from the service
  getAllMovies() {
    this.movieService.getAllMovie().subscribe({
      next: (res: any) => {
        this.allMovies = res.data;
        this.filteredMovies = res.data;  // Initially display all movies
      }
    });
  }

  // Filter movies based on the search query
  filterMovies() {
    if (this.searchQuery) {
      // Filter movies by title (case-insensitive)
      this.filteredMovies = this.allMovies.filter(movie =>
        movie.movieTitle.toLowerCase().includes(this.searchQuery.toLowerCase())
      );
    } else {
      // If the search query is empty, show all movies
      this.filteredMovies = this.allMovies;
    }
  }


}
