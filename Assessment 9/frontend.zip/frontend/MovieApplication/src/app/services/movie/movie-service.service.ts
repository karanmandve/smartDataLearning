import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MovieServiceService {

http = inject(HttpClient);

addMovie(movieData: any): Observable<any>{
  return this.http.post("https://localhost:7228/api/Movie/add-movie", movieData)
}

getMoviesOfAdmin(adminId: number): Observable<any>{
  return this.http.get(`https://localhost:7228/api/Movie/get-movie-data-by-adminId/${adminId}`)
}

deleteMovie(movieId: number): Observable<any>{
  return this.http.delete(`https://localhost:7228/api/Movie/delete-movie/${movieId}`)
}

updateMovie(movieData: any): Observable<any>{
  return this.http.put("https://localhost:7228/api/Movie/update-movie", movieData)
}

getAllMovie(){
  return this.http.get("https://localhost:7228/api/Movie/get-all-movie")
}


}
