﻿using core.Interface;
using FluentEmail.Core;

namespace core.Service
{
    public class MailgunEmailService : IMailgunEmailService
    {
        private readonly IFluentEmail _fluentEmail;

        public MailgunEmailService(IFluentEmail fluentEmail)
        {
            _fluentEmail = fluentEmail;
        }

        public async Task<bool> SendEmailAsync(string to, string subject, string body)
        {
            var email = _fluentEmail
           .To(to)
           .Subject(subject)
           .Body(body, true)
           .SetFrom("noreply@email.karanmandve.me", "Movie Application");

            var response = await email.SendAsync();

            return response.Successful;
        }
    }
}
