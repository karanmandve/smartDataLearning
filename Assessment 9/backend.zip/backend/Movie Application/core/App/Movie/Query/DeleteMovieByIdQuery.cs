﻿using core.API_Response;
using core.Interface;
using Dapper;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace core.App.Movie.Query
{
    public class DeleteMovieByIdQuery : IRequest<AppResponse<object>>
    {
        public int MovieId { get; set; }
    }

    public class DeleteMovieByIdCommandHandler : IRequestHandler<DeleteMovieByIdQuery, AppResponse<object>>
    {
        private readonly IAppDbContext _context;

        public DeleteMovieByIdCommandHandler(IAppDbContext context)
        {
            _context = context;
        }

        public async Task<AppResponse<object>> Handle(DeleteMovieByIdQuery request, CancellationToken cancellationToken)
        {
            var movie = await _context.Set<domain.Model.Movie.Movie>().FindAsync(request.MovieId);

            if (movie == null)
            {
                return AppResponse.Fail<object>(message: "Movie not found", statusCode: HttpStatusCodes.NotFound);
            }

            using var connection = _context.GetConnection();

            var query = "DELETE FROM Movies WHERE Id = @MovieId;";

            await connection.QueryAsync<object>(query, new { MovieId = request.MovieId });

            return AppResponse.Success<object>(null, "Successfully Deleted Movie", HttpStatusCodes.OK);
        }
    }
}
