﻿using core.API_Response;
using core.Interface;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace core.App.Movie.Query
{
    public class GetAllMovieQuery : IRequest<AppResponse<object>>
    {
    }

    public class GetAllMovieQueryHandler : IRequestHandler<GetAllMovieQuery, AppResponse<object>>
    {
        private readonly IAppDbContext _context;

        public GetAllMovieQueryHandler(IAppDbContext context)
        {
            _context = context;
        }

        public async Task<AppResponse<object>> Handle(GetAllMovieQuery request, CancellationToken cancellationToken)
        {
            var movieData = await _context.Set<domain.Model.Movie.Movie>().ToListAsync();

            return AppResponse.Success<object>(movieData, "Successfully Fetch Movie Data", HttpStatusCodes.OK);
        }
    }
}
