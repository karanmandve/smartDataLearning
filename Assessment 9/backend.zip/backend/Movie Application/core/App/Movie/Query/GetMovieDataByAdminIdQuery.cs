﻿using core.API_Response;
using core.Interface;
using Dapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace core.App.Movie.Query
{
    public class GetMovieDataByAdminIdQuery : IRequest<AppResponse<object>>
    {
        public int AdminId { get; set; }
    }

    public class GetMovieDataByAdminIdQueryHandler : IRequestHandler<GetMovieDataByAdminIdQuery, AppResponse<object>>
    {
        private readonly IAppDbContext _context;
        public GetMovieDataByAdminIdQueryHandler(IAppDbContext context)
        {
            _context = context;
        }
        public async Task<AppResponse<object>> Handle(GetMovieDataByAdminIdQuery request, CancellationToken cancellationToken)
        {
            var movieData = await _context.Set<domain.Model.Movie.Movie>().Where(mov => mov.AdminId == request.AdminId).ToListAsync();

            return AppResponse.Success<object>(movieData, "Successfully Fetch Movie Data", HttpStatusCodes.OK);
        }
    }

}
