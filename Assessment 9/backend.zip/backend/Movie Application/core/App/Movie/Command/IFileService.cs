﻿namespace core.App.Movie.Command
{
    internal interface IFileService
    {
    }
}