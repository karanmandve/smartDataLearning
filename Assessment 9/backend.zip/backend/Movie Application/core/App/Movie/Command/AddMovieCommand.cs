﻿using AutoMapper;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using core.API_Response;
using core.App.User.Command;
using core.Interface;
using core.Service;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace core.App.Movie.Command
{
    public class AddMovieCommand : IRequest<AppResponse<object>>
    {
        public Stream FileStream { get; set; }
        public string FileName { get; set; }
        public domain.ModelDto.MovieDto MovieData { get; set; }

    }

    public class AddMovieCommandHandler : IRequestHandler<AddMovieCommand, AppResponse<object>>
    {
        private readonly IAppDbContext _context;
        private readonly string _connectionString;
        private readonly string _containerName = "ehrapplication";
        private readonly string _folderName = "movie-poster-images";
        private readonly IMapper _mapper;

        public AddMovieCommandHandler(IAppDbContext context, IConfiguration configuration, IEmailService emailService, IMapper mapper)
        {
            _context = context;
            _connectionString = configuration.GetConnectionString("AzureBlobStorage");
            _mapper = mapper;
        }

        public async Task<AppResponse<object>> Handle(AddMovieCommand request, CancellationToken cancellationToken)
        {
            var movieData = request.MovieData;

            var movieAlreadyExist = await _context.Set<domain.Model.Movie.Movie>().FirstOrDefaultAsync(us => us.MovieTitle == movieData.MovieTitle);

            if (movieAlreadyExist != null)
            {
                return AppResponse.Fail<object>(message: "Movie Already Exist", statusCode: HttpStatusCodes.Conflict);
            }

            // STORING IMAGES
            var blobServiceClient = new BlobServiceClient(_connectionString);
            var blobContainerClient = blobServiceClient.GetBlobContainerClient(_containerName);
            var blobClient = blobContainerClient.GetBlobClient($"{_folderName}/{Guid.NewGuid()}");

            var blobHttpHeaders = new BlobHttpHeaders
            {
                ContentType = GetContentType(request.FileName) // Get MIME type dynamically
            };

            await blobClient.UploadAsync(request.FileStream, new BlobUploadOptions
            {
                HttpHeaders = blobHttpHeaders
            });

            var movieImageUrl = blobClient.Uri.ToString();


            var transformMovieData = _mapper.Map<domain.Model.Movie.Movie>(movieData);

            transformMovieData.MoviePosterImageUrl = movieImageUrl;

            await _context.Set<domain.Model.Movie.Movie>().AddAsync(transformMovieData);
            await _context.SaveChangesAsync(cancellationToken);



            return AppResponse.Success<object>(message: "Movie Added Successfully", statusCode: HttpStatusCodes.OK);

        }

        private string GetContentType(string fileName)
        {
            return fileName.EndsWith(".jpg") || fileName.EndsWith(".jpeg") ? "image/jpeg" :
                   fileName.EndsWith(".png") ? "image/png" :
                   "application/octet-stream";
        }
    }
}
