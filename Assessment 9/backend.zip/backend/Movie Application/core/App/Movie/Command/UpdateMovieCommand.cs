﻿using Azure.Storage.Blobs.Models;
using Azure.Storage.Blobs;
using core.API_Response;
using core.Interface;
using MediatR;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace core.App.Movie.Command
{
    public class UpdateMovieCommand : IRequest<AppResponse<object>>
    {
        public Stream FileStream { get; set; }
        public string FileName { get; set; }
        public domain.ModelDto.MovieDto Movie { get; set; }
    }

    public class UpdateMovieCommandHandler : IRequestHandler<UpdateMovieCommand, AppResponse<object>>
    {
        private readonly IAppDbContext _context;
        private readonly string _connectionString;
        private readonly string _containerName = "ehrapplication";
        private readonly string _folderName = "movie-poster-images";

        public UpdateMovieCommandHandler(IAppDbContext appDbContext, IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("AzureBlobStorage");
            _context = appDbContext;
        }

        public async Task<AppResponse<object>> Handle(UpdateMovieCommand request, CancellationToken cancellationToken)
        {
            var id = request.Movie.Id;

            var movie = await _context.Set<domain.Model.Movie.Movie>().FindAsync(id);

            if (movie == null)
            {
                return AppResponse.Fail<object>(message: "Movie Not Found", statusCode: HttpStatusCodes.NotFound);
            }

            var imageUrl = string.Empty;

            if (request.FileName != null)
            {
                // STORING IMAGES
                var blobServiceClient = new BlobServiceClient(_connectionString);
                var blobContainerClient = blobServiceClient.GetBlobContainerClient(_containerName);
                var blobClient = blobContainerClient.GetBlobClient($"{_folderName}/{Guid.NewGuid()}");

                var blobHttpHeaders = new BlobHttpHeaders
                {
                    ContentType = GetContentType(request.FileName) // Get MIME type dynamically
                };

                await blobClient.UploadAsync(request.FileStream, new BlobUploadOptions
                {
                    HttpHeaders = blobHttpHeaders
                });

                imageUrl = blobClient.Uri.ToString();
            }

            movie.MovieTitle = request.Movie.MovieTitle;
            movie.ReleaseYear = request.Movie.ReleaseYear;
            if (!string.IsNullOrEmpty(imageUrl))
            {
                movie.MoviePosterImageUrl = imageUrl;
            }

            await _context.SaveChangesAsync(cancellationToken);

            return AppResponse.Success<object>(message: "Movie Updated Successfully", statusCode: HttpStatusCodes.OK);
        }

        private string GetContentType(string fileName)
        {
            return fileName.EndsWith(".jpg") || fileName.EndsWith(".jpeg") ? "image/jpeg" :
                   fileName.EndsWith(".png") ? "image/png" :
                   "application/octet-stream"; // Default fallback
        }
    }
}
