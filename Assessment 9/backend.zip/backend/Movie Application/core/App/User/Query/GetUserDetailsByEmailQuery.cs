﻿using AutoMapper;
using core.API_Response;
using core.Interface;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace core.App.User.Query
{
    public class GetUserDetailsByEmailQuery : IRequest<AppResponse<object>>
    {
        public string Email { get; set; }
    }

    public class GetUserDetailsByEmailQueryHandler : IRequestHandler<GetUserDetailsByEmailQuery, AppResponse<object>>
    {
        private readonly IAppDbContext _context;
        private readonly IMapper _mapper;

        public GetUserDetailsByEmailQueryHandler(IAppDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }
        public async Task<AppResponse<object>> Handle(GetUserDetailsByEmailQuery request, CancellationToken cancellationToken)
        {
            var email = request.Email;
            var user = await _context.Set<domain.Model.User.User>().FirstOrDefaultAsync(x => x.Email == email);

            if (user == null)
            {
                return AppResponse.Fail<object>(message: "User Not Found", statusCode: HttpStatusCodes.NotFound);
            }

            var userDetail = _mapper.Map<domain.ModelDto.UserDetailsDto>(user);

            return AppResponse.Success<object>(userDetail, "Successfully Fetch User", HttpStatusCodes.OK);

        }
    }
}
