﻿using AutoMapper;
using core.API_Response;
using core.Interface;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace core.App.User.Command
{
    public class CreateUserCommand : IRequest<AppResponse<object>>
    {
        public domain.ModelDto.RegisterDto UserData { get; set; }
    }

    public class CreateUserCommandHandler : IRequestHandler<CreateUserCommand, AppResponse<object>>
    {
        private readonly IAppDbContext _context;
        private readonly IMapper _mapper;

        public CreateUserCommandHandler(IAppDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<AppResponse<object>> Handle(CreateUserCommand request, CancellationToken cancellationToken)
        {

            var userAlreadyExist = await _context.Set<domain.Model.User.User>().FirstOrDefaultAsync(us => us.Email == request.UserData.Email);

            if (userAlreadyExist != null)
            {
                return AppResponse.Fail<object>(message: "User Already Exist", statusCode: HttpStatusCodes.Conflict);
            }

            var registerUserData = _mapper.Map<domain.Model.User.User>(request.UserData);

            registerUserData.Password = BCrypt.Net.BCrypt.HashPassword(registerUserData.Password, 13);

            await _context.Set<domain.Model.User.User>().AddAsync(registerUserData);
            await _context.SaveChangesAsync(cancellationToken);

            return AppResponse.Success<object>(message: "User Created Successfully", statusCode: HttpStatusCodes.Created);

        }
    }
}
