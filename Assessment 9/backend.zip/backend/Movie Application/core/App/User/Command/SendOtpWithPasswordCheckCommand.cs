﻿using core.API_Response;
using core.Interface;
using domain.Model.Otp;
using domain.Model.User;
using domain.ModelDto;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace core.App.User.Command
{
    public class SendOtpWithPasswordCheckCommand : IRequest<AppResponse<object>>
    {
        public SendOtpWithPasswordCheckDto SendOtpWithPasswordData { get; set; }
    }

    public class SendOtpWithPasswordCheckCommandHandler : IRequestHandler<SendOtpWithPasswordCheckCommand, AppResponse<object>>
    {
        private readonly IAppDbContext _context;
        private readonly IMailgunEmailService _emailService; // Add email service

        public SendOtpWithPasswordCheckCommandHandler(IAppDbContext context, IConfiguration configuration, IMailgunEmailService emailService)
        {
            _context = context;
            _emailService = emailService;
        }

        public async Task<AppResponse<object>> Handle(SendOtpWithPasswordCheckCommand request, CancellationToken cancellationToken)
        {
            var email = request.SendOtpWithPasswordData.Email;
            var password = request.SendOtpWithPasswordData.Password;

            var existingUser = await _context.Set<domain.Model.User.User>().FirstOrDefaultAsync(x => x.Email == email);

            if (existingUser == null || !BCrypt.Net.BCrypt.Verify(password, existingUser.Password))
            {
                return AppResponse.Fail<object>(message: "User Not Exist", statusCode: HttpStatusCodes.NotFound);
            }


            var otp = new Random().Next(100000, 999999).ToString();

            await _context.Set<Otp>().AddAsync(new domain.Model.Otp.Otp { Email = existingUser.Email, Code = otp, Expiration = DateTime.Now.AddMinutes(5) });
            await _context.SaveChangesAsync();


            var emailBody = $@"
                            <html>
                              <body style='font-family: Arial, sans-serif; background-color: #f0f8ff; margin: 0; padding: 0;'>
                                <table width='100%' cellpadding='0' cellspacing='0' style='padding: 20px;'>
                                  <tr>
                                    <td align='center' style='background-color: #0077b6; padding: 20px; color: white; font-size: 28px; font-weight: bold; text-align: center;'>
                                      <h1 style='margin: 0; color: white; font-size: 30px;'>MovieApp</h1>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td style='background-color: white; padding: 40px; border-radius: 8px; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);'>
                                      <p style='font-size: 18px; color: #0077b6; margin-bottom: 20px;'>Dear {existingUser.FirstName},</p>
                                      <p style='font-size: 16px; color: #333; margin-bottom: 20px;'>Thank you for using our service. Your OTP is:</p>
                                      <p style='font-size: 24px; color: #333; font-weight: bold; margin: 20px 0; padding: 10px; border-radius: 5px; background-color: #e1f5fe; display: inline-block;'>{otp}</p>
                                      <p style='font-size: 16px; color: #333; margin-top: 20px;'>Please use this OTP within the next 5 minutes. If you did not request this, please ignore this email.</p>
                                      <p style='font-size: 16px; color: #0077b6; margin-top: 20px;'>Best regards,<br>The MovieApp Team</p>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td align='center' style='background-color: #0077b6; padding: 20px; color: white; font-size: 14px;'>
                                      <p>© {DateTime.Now.Year} MovieApp. All rights reserved.<br>Your partner in entertainment.</p>
                                    </td>
                                  </tr>
                                </table>
                              </body>
                            </html>";

            var isEmailSend = await _emailService.SendEmailAsync(
                existingUser.Email,
                "Your OTP for MovieApp",
                emailBody
            );

            if (!isEmailSend)
            {
                return AppResponse.Fail<object>(message: "Failed to send OTP", statusCode: HttpStatusCodes.InternalServerError);
            }

            return AppResponse.Success<object>(message: "OTP sent to your email", statusCode: HttpStatusCodes.OK);
        }
    }


}
