﻿using domain.Model.User;
using System.ComponentModel.DataAnnotations.Schema;

namespace domain.ModelDto
{
    public class UserDetailsDto
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public int RoleId { get; set; }

    }
}
