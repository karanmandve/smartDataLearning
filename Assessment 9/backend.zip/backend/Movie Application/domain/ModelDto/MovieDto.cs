﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace domain.ModelDto
{
    public class MovieDto
    {
        public int Id { get; set; }
        public string MovieTitle { get; set; }
        public string ReleaseYear { get; set; }
        public IFormFile? MoviePosterImage { get; set; }
        public int AdminId { get; set; }
    }
}
