﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace domain.Model.Movie
{
    public class Movie
    {
        public int Id { get; set; }
        public string MovieTitle { get; set; }
        public string ReleaseYear { get; set; }
        public string MoviePosterImageUrl { get; set; }
        public int AdminId { get; set; }
    }
}
