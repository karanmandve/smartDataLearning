﻿using domain.ModelDto;
using FluentValidation;
using Microsoft.AspNetCore.Http;

namespace domain.ModelDtoValidators
{
    public class MovieDtoValidator : AbstractValidator<MovieDto>
    {

        public MovieDtoValidator()
        {
            RuleFor(x => x.MovieTitle)
                .NotEmpty().WithMessage("Movie title is required.")
                .MinimumLength(1).WithMessage("Movie title must be at least 1 characters long.")
                .MaximumLength(100).WithMessage("Movie title must be no more than 100 characters.")
                .Matches(@"^[A-Za-z0-9\s]+$").WithMessage("Movie title can only contain letters, numbers, and spaces.");

            // Validate ReleaseYear: Should be a valid DateOnly and a realistic release year (e.g., 1900 to current year)
            RuleFor(x => x.ReleaseYear)
                .NotEmpty().WithMessage("Release year is required.")
                .Must(year => IsValidYear(year)).WithMessage("Release year must be a valid year between 1900 and the next 5 years.")
                .Must(year => IsWithinRange(year)).WithMessage("Release year must be between 1900 and 5 years into the future.");


            // Validate MoviePosterImage: Check if it's not null and if the file size is reasonable (example: max 5MB)
            RuleFor(x => x.MoviePosterImage)
                .NotNull().WithMessage("Movie poster image is required.")
                .Must(file => file.Length > 0).WithMessage("Movie poster image cannot be empty.")
                .Must(file => file.Length <= 5 * 1024 * 1024).WithMessage("Movie poster image cannot exceed 5MB.")
                .Must(file => IsValidImageFile(file)).WithMessage("Movie poster must be a valid image (JPEG, JPG, PNG).");

        }

        private bool IsValidYear(string year)
        {
            return int.TryParse(year, out int parsedYear);
        }

        private bool IsWithinRange(string year)
        {
            if (int.TryParse(year, out int parsedYear))
            {
                int currentYear = DateTime.Now.Year;
                return parsedYear >= 1900 && parsedYear <= currentYear + 5;
            }
            return false;
        }

        private bool IsValidImageFile(IFormFile file)
        {
            // Check the file's content type (MIME type)
            var contentType = file.ContentType.ToLower();
            return contentType == "image/jpeg" || contentType == "image/jpg" || contentType == "image/png";
        }

    }
}
