﻿using AutoMapper;
using domain.Model.Movie;
using domain.Model.User;
using domain.ModelDto;

namespace EHR_Application.Mapping
{
    public class AutomapperProfile : Profile
    {
        public AutomapperProfile()
        {
            CreateMap<RegisterDto, User>();
            CreateMap<User, UserDetailsDto>();
            CreateMap<MovieDto, Movie>().ForMember(dest => dest.Id, opt => opt.Ignore());
        }
    }
}
