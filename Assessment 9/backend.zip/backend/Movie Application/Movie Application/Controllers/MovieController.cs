﻿using core.App.Movie.Command;
using core.App.Movie.Query;
using core.App.User.Command;
using domain.ModelDtoValidators;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace EHR_Application.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MovieController : ControllerBase
    {
        private readonly IMediator _mediator;
        public MovieController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpPost("add-movie")]
        public async Task<IActionResult> AddMovie(domain.ModelDto.MovieDto model)
        {
            var validator = new MovieDtoValidator();
            var isModeltValid = validator.Validate(model);

            if (!isModeltValid.IsValid)
            {
                var errorMessage = isModeltValid.Errors[0].ErrorMessage;
                return BadRequest(new { Errors = isModeltValid.Errors.Select(x => x.ErrorMessage).ToList() });
            }

            using (var stream = model.MoviePosterImage.OpenReadStream())
            {
                var command = new AddMovieCommand
                {
                    FileStream = stream,
                    FileName = model.MoviePosterImage.FileName,
                    MovieData = model
                };

                var result = await _mediator.Send(command);

                if (!result.IsSuccess)
                {
                    return Conflict(result);
                }

                return Ok(result);
            }

        }

        [HttpGet("get-movie-data-by-adminId/{adminId}")]
        public async Task<IActionResult> GetMovieDataByAdminId(int adminId)
        {
            var result = await _mediator.Send(new GetMovieDataByAdminIdQuery { AdminId = adminId });

            if (!result.IsSuccess)
            {
                return NotFound(result);
            }

            return Ok(result);
        }


        [HttpDelete("delete-movie/{movieId}")]
        public async Task<IActionResult> DeleteMovie(int movieId)
        {
            var result = await _mediator.Send(new DeleteMovieByIdQuery { MovieId = movieId });

            if (!result.IsSuccess)
            {
                return NotFound(result);
            }

            return Ok(result);
        }


        [HttpPut("update-movie")]
        public async Task<IActionResult> UpdateMovie(domain.ModelDto.MovieDto model)
        {
            if (model.MoviePosterImage == null)
            {
                var command = new UpdateMovieCommand
                {
                    FileStream = null,
                    FileName = null,
                    Movie = model
                };

                var result = await _mediator.Send(command);
                if (!result.IsSuccess)
                {
                    return NotFound(result);
                }
                return Ok(result);
            }

            using (var stream = model.MoviePosterImage.OpenReadStream())
            {
                var command = new UpdateMovieCommand
                {
                    FileStream = stream,
                    FileName = model.MoviePosterImage.FileName,
                    Movie = model
                };

                var result = await _mediator.Send(command);
                if (!result.IsSuccess)
                {
                    return NotFound(result);
                }
                return Ok(result);
            }
        }

        [HttpGet("get-all-movie")]
        public async Task<IActionResult> GetAllMovie()
        {
            var result = await _mediator.Send(new GetAllMovieQuery());

            if (!result.IsSuccess)
            {
                return NotFound(result);
            }

            return Ok(result);
        }




    }
}
