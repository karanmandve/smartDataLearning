﻿using Amazon;
using Amazon.Runtime;
using Amazon.Textract;
using Amazon.Textract.Model;
using AWSServices.Interface;
using System.Globalization;
using System.Text.Json;
using System.Text.RegularExpressions;


namespace AWSServices.Services
{
    public class TextractService : ITextractService
    {
        private readonly IAmazonTextract _textractClient;
        private readonly IConfiguration _configuration;

        // Define synonyms for each field so we can handle multiple check layouts
        private static readonly Dictionary<string, string[]> FieldSynonyms = new Dictionary<string, string[]>
        {
            { "payee_name",        new[] { "PAY TO THE ORDER OF", "PAYEE", "PAYEE NAME" } },
            { "date",              new[] { "DATE", "DATE:", "DT." } },
            { "check_number",      new[] { "CHECK NO", "CHECK NUMBER", "CHEQUE NO", "CHEQUE NUMBER", "CHQ NO" } },
            { "memo",              new[] { "MEMO", "RE", "NOTES" } },
            { "amount_in_words",   new[] { "DOLLARS", "AMOUNT IN WORDS", "AMOUNT WORDS" } },
            { "signature",         new[] { "AUTHORIZED SIGNATURE", "SIGNATURE", "SIG" } },
            { "account_number",    new[] { "ACCOUNT NO", "AC NO", "ACCOUNT #", "A/C NUMBER" } },
            { "routing_number",    new[] { "ROUTING NO", "ROUTING #", "BANK CODE" } },
            // You may add more synonyms as needed
        };

        public TextractService(IAmazonTextract textractClient, IConfiguration configuration)
        {
            _configuration = configuration;
            // Either use the injected textractClient or build one with credentials from configuration
            var credentials = new BasicAWSCredentials(configuration["AWS:AccessKey"], configuration["AWS:SecretKey"]);
            var textractConfig = new AmazonTextractConfig { RegionEndpoint = RegionEndpoint.APSouth1 };
            _textractClient = new AmazonTextractClient(credentials, textractConfig);
        }

        public async Task<string> ExtractFormsFromS3(string bucketName, string fileName)
        {
            // 1. Call Textract to analyze the document with FORMS feature
            var request = new AnalyzeDocumentRequest
            {
                Document = new Document
                {
                    S3Object = new S3Object
                    {
                        Bucket = bucketName,
                        Name = fileName
                    }
                },
                FeatureTypes = new List<string> { "FORMS" }
            };

            var response = await _textractClient.AnalyzeDocumentAsync(request);
            var options = new JsonSerializerOptions { WriteIndented = true };
            string jsonResponse = JsonSerializer.Serialize(response, options);

            // Print the JSON string to the console (optional)
            Console.WriteLine(jsonResponse);

            // 2. Process Textract response to get key-value pairs
            var extractedData = ProcessTextractResponse(response);
            // 3. Extract payor address lines (naïve approach: first 3 LINE blocks)
            var (payorLines, payorConfs) = ExtractPayorAddressLines(response);

            // 4. Aggregate text from the extracted key-value pairs for Comprehend analysis
            //string aggregatedText = string.Join(" ", extractedData.Select(kvp => $"{kvp.Key} {kvp.Value.Text}"));

            var requestTextractDetect = new DetectDocumentTextRequest
            {
                Document = new Document
                {
                    S3Object = new Amazon.Textract.Model.S3Object
                    {
                        Bucket = bucketName,
                        Name = fileName
                    }
                }
            };

            var responseTextractDetect = await _textractClient.DetectDocumentTextAsync(requestTextractDetect);
            string extractedText = "";
            foreach (var block in responseTextractDetect.Blocks)
            {
                if (block.BlockType == "LINE")
                {
                    // Skip the line if it has more than 40 characters
                    if (block.Text.Length > 40)
                        continue;
                    extractedText += block.Text + "\n";
                }
            }
            // 5. Call Amazon Comprehend to detect entities in the aggregated text
            var comprehendEntities = await AnalyzeEntitiesWithComprehend(extractedText);
            // 6. Map the Textract data (plus payor lines and comprehend entities) into our final models
            var (checkDetails, confidence) = MapToCheckDetails(extractedData, payorLines, payorConfs, comprehendEntities);

            // 7. Wrap all results into the final output object
            var result = new CheckExtractionResult
            {
                Check_details = checkDetails,
                Confidence = confidence,
                Comprehend_entities = comprehendEntities,
                textractDocData = extractedText
            };

            return JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true });
        }

        /// <summary>
        /// Processes Textract blocks into a dictionary mapping "raw key" to a KeyValueInfo (text + averaged confidence).
        /// </summary>
        private Dictionary<string, KeyValueInfo> ProcessTextractResponse(AnalyzeDocumentResponse response)
        {
            var formFields = new Dictionary<string, KeyValueInfo>(StringComparer.OrdinalIgnoreCase);
            // Build a map of blockId -> Block for quick lookup
            var blockMap = response.Blocks.ToDictionary(b => b.Id, b => b);
            // Separate blocks into KEY and VALUE sets
            var keyBlocks = new List<Block>();
            var valueBlocks = new List<Block>();

            foreach (var block in response.Blocks)
            {
                if (block.BlockType == BlockType.KEY_VALUE_SET && block.EntityTypes.Contains("KEY"))
                    keyBlocks.Add(block);
                else if (block.BlockType == BlockType.KEY_VALUE_SET && block.EntityTypes.Contains("VALUE"))
                    valueBlocks.Add(block);
            }

            // For each KEY block, find its associated VALUE block(s)
            foreach (var keyBlock in keyBlocks)
            {
                var keyText = GetText(keyBlock, blockMap);
                float keyConfidence = keyBlock.Confidence;

                if (string.IsNullOrWhiteSpace(keyText))
                    continue;

                var valueBlockIds = keyBlock.Relationships?
                    .Where(r => r.Type == RelationshipType.VALUE)
                    .SelectMany(r => r.Ids)
                    .ToList();

                if (valueBlockIds == null || valueBlockIds.Count == 0)
                    continue;

                foreach (var valueBlockId in valueBlockIds)
                {
                    if (!blockMap.TryGetValue(valueBlockId, out var valBlock))
                        continue;

                    var valText = GetText(valBlock, blockMap);
                    float valConfidence = valBlock.Confidence;

                    if (string.IsNullOrWhiteSpace(valText))
                        continue;

                    // Average the KEY and VALUE confidence as a single score
                    var avgConfidence = (keyConfidence + valConfidence) / 2f;

                    formFields[keyText] = new KeyValueInfo
                    {
                        Text = valText,
                        Confidence = avgConfidence
                    };
                }
            }

            return formFields;
        }

        /// <summary>
        /// Naïve approach: Takes the first three LINE blocks (ordered top-to-bottom, left-to-right)
        /// and treats them as payor_line1, payor_line2, and payor_line3.
        /// </summary>
        private (List<string> lines, List<double> confs) ExtractPayorAddressLines(AnalyzeDocumentResponse response)
        {
            var lineBlocks = response.Blocks
                .Where(b => b.BlockType == BlockType.LINE)
                .OrderBy(b => b.Geometry.BoundingBox.Top)
                .ThenBy(b => b.Geometry.BoundingBox.Left)
                .ToList();

            var topThree = lineBlocks.Take(3).ToList();
            var lines = new List<string>();
            var confs = new List<double>();
            foreach (var block in topThree)
            {
                lines.Add(block.Text ?? "");
                confs.Add(block.Confidence);
            }

            return (lines, confs);
        }

        /// <summary>
        /// Recursively extracts text from a block (including its child blocks).
        /// </summary>
        private string GetText(Block block, Dictionary<string, Block> blockMap)
        {
            var text = block.Text ?? "";

            if (block.Relationships != null)
            {
                foreach (var rel in block.Relationships)
                {
                    if (rel.Type == RelationshipType.CHILD)
                    {
                        foreach (var childId in rel.Ids)
                        {
                            if (blockMap.TryGetValue(childId, out var childBlock))
                            {
                                if (!string.IsNullOrWhiteSpace(childBlock.Text))
                                    text += " " + childBlock.Text;
                            }
                        }
                    }
                }
            }

            return text.Trim();
        }

        /// <summary>
        /// Calls Amazon Comprehend to detect entities in the provided text.
        /// </summary>
        private async Task<List<ComprehendEntity>> AnalyzeEntitiesWithComprehend(string text)
        {
            var credentials = new BasicAWSCredentials(_configuration["AWS:AccessKey"], _configuration["AWS:SecretKey"]);
            using var comprehendClient = new Amazon.Comprehend.AmazonComprehendClient(credentials, RegionEndpoint.APSouth1);

            var request = new Amazon.Comprehend.Model.DetectEntitiesRequest
            {
                Text = text,
                LanguageCode = "en"
            };

            var response = await comprehendClient.DetectEntitiesAsync(request);
            var entities = new List<ComprehendEntity>();

            foreach (var entity in response.Entities)
            {
                entities.Add(new ComprehendEntity
                {
                    Text = entity.Text,
                    Type = entity.Type,
                    Score = entity.Score
                });
            }

            return entities;
        }

        /// <summary>
        /// Maps the extracted key-value pairs, payor address lines, and Comprehend entities
        /// into our strongly typed models.
        /// 
        /// Mapping for the payor address is done as follows:
        /// - Payor_line1: A PERSON entity (from Comprehend) representing the drawer’s name.
        /// - Payor_line2: The location/address without the zipcode.
        /// - Payor_line3: The full location/address including the zipcode.
        /// If a zipcode isn’t detected, both line2 and line3 will have the same location text.
        /// </summary>
        private (CheckDetails, CheckConfidence) MapToCheckDetails(
            Dictionary<string, KeyValueInfo> extracted,
            List<string> payorLines,
            List<double> payorConfs,
            List<ComprehendEntity> comprehendEntities)
        {
            var details = new CheckDetails
            {
                // Default/fallback values
                Payor_line1 = "Unknown",
                Payor_line2 = "Unknown",
                Payor_line3 = "Unknown",
                Check_number = "",
                Date = "",
                Payee_name = "",
                Amount_in_numbers = 0.0,
                Amount_in_words = "",
                Is_amount_match = "Not Sure",
                Memo = "",
                Is_signed = "No",
                Signature = "",
                Routing_number = "",
                Account_number = "",
                Is_handwritten = "Sure"
            };

            var conf = new CheckConfidence
            {
                Payor_line1 = 0.0,
                Payor_line2 = 0.0,
                Payor_line3 = 0.0,
                Check_number = 0.0,
                Date = 0.0,
                Payee_name = 0.0,
                Amount_in_numbers = 0.0,
                Amount_in_words = 0.0,
                Memo = 0.0,
                Signature = 0.0,
                Routing_number = 0.0,
                Account_number = 0.0
            };

            // Local helper function to find field values based on synonyms.
            KeyValueInfo FindBySynonyms(string field)
            {
                if (FieldSynonyms.TryGetValue(field, out var synonyms))
                {
                    foreach (var synonym in synonyms)
                    {
                        var normalized = synonym.Trim().TrimEnd(':');
                        foreach (var kvp in extracted)
                        {
                            if (kvp.Key.IndexOf(normalized, StringComparison.OrdinalIgnoreCase) >= 0)
                                return kvp.Value;
                        }
                    }
                }
                return null;
            }

            // 1) Map Payee Name using Textract synonyms first; fallback to Comprehend PERSON entities.
            var payeeInfo = FindBySynonyms("payee_name");
            if (payeeInfo != null)
            {
                details.Payee_name = payeeInfo.Text;
                conf.Payee_name = payeeInfo.Confidence;
            }
            else
            {
                var personEntities = comprehendEntities
                    .Where(e => e.Type.Equals("PERSON", StringComparison.OrdinalIgnoreCase))
                    .Select(e => e.Text)
                    .Distinct()
                    .ToList();
                if (personEntities.Any())
                {
                    details.Payee_name = personEntities.First();
                    conf.Payee_name = 0.95;
                }
            }

            // 2) Map Payor_line1 strictly from Comprehend PERSON entities (excluding the payee)
            var personCandidates = comprehendEntities
        .Where(e => e.Type.Equals("PERSON", StringComparison.OrdinalIgnoreCase) &&
                    (string.IsNullOrWhiteSpace(details.Payee_name) ||
                     !Regex.IsMatch(e.Text, $@"\b{Regex.Escape(details.Payee_name)}\b", RegexOptions.IgnoreCase)))
        .Select(e => e.Text)
        .Distinct()
        .ToList();

            if (personCandidates.Any())
            {
                string candidate = personCandidates.First();
                var words = candidate.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

                // If candidate has only one word and there's a second candidate, join them
                if (words.Length < 2 && personCandidates.Count > 1)
                {
                    candidate = personCandidates[1];
                }

                details.Payor_line1 = candidate;
                conf.Payor_line1 = 0.95;
            }
            else
            {
                details.Payor_line1 = "Unknown";
                conf.Payor_line1 = 0.00;

            }

            // 3) Map Payor_line2 and Payor_line3 using LOCATION entities.
            // Expectation:
            // - Payor_line2: Address without zipcode.
            // - Payor_line3: Full address (including zipcode).
            var locationCandidates = comprehendEntities
                .Where(e => e.Type.Equals("LOCATION", StringComparison.OrdinalIgnoreCase))
                .Select(e => e.Text)
                .Distinct()
                .ToList();

            if (locationCandidates.Any())
            {
                string fullLocation = locationCandidates.First();

                // Check if the location text contains newline characters.
                if (fullLocation.Contains("\n"))
                {
                    // Split the location text by newline.
                    var parts = fullLocation.Split(new[] { "\n" }, StringSplitOptions.RemoveEmptyEntries);
                    if (parts.Length >= 2)
                    {
                        details.Payor_line2 = parts[0].Trim();
                        details.Payor_line3 = parts[1].Trim();

                        // Optionally, if the second part lacks a zipcode, try to find one.
                        var zipMatch = Regex.Match(parts[1], @"\b\d{5}\b");
                        if (!zipMatch.Success)
                        {
                            zipMatch = Regex.Match(fullLocation, @"\b\d{5}\b");
                            if (zipMatch.Success)
                            {
                                details.Payor_line3 = $"{parts[1].Trim()} {zipMatch.Value}";
                            }
                            else if (locationCandidates.Count >= 2)
                            {
                                // If no zipcode and more than one location candidate exists, use the first two.
                                details.Payor_line2 = locationCandidates[0].Trim();
                                details.Payor_line3 = locationCandidates[1].Trim();
                            }
                        }
                        conf.Payor_line2 = 0.95;
                        conf.Payor_line3 = 0.95;
                    }
                    else
                    {
                        // Only one part available from newline splitting.
                        var zipMatch = Regex.Match(fullLocation, @"\b\d{5}\b");
                        if (zipMatch.Success)
                        {
                            details.Payor_line2 = fullLocation.Replace(zipMatch.Value, "").Trim();
                            details.Payor_line3 = fullLocation;
                        }
                        else if (locationCandidates.Count >= 2)
                        {
                            // Use two separate location candidates if available.
                            details.Payor_line2 = locationCandidates[0].Trim();
                            details.Payor_line3 = locationCandidates[1].Trim();
                        }
                        else
                        {
                            details.Payor_line2 = fullLocation;
                            details.Payor_line3 = fullLocation;
                        }
                        conf.Payor_line2 = 0.95;
                        conf.Payor_line3 = 0.95;
                    }
                }
                else
                {
                    // No newline found; check for a zipcode.
                    var zipMatch = Regex.Match(fullLocation, @"\b\d{5}\b");
                    if (zipMatch.Success)
                    {
                        details.Payor_line2 = fullLocation.Replace(zipMatch.Value, "").Trim();
                        details.Payor_line3 = fullLocation;
                    }
                    else
                    {
                        // No zipcode: if there is more than one candidate, use the first two.
                        if (locationCandidates.Count >= 2)
                        {
                            details.Payor_line2 = locationCandidates[0].Trim();
                            details.Payor_line3 = locationCandidates[1].Trim();
                        }
                        else
                        {
                            details.Payor_line2 = fullLocation;
                            details.Payor_line3 = fullLocation;
                        }
                    }
                    conf.Payor_line2 = 0.95;
                    conf.Payor_line3 = 0.95;
                }
            }
            else if (payorLines.Count > 1)
            {
                // Fallback: Use Textract's extracted lines.
                details.Payor_line2 = payorLines[1];
                conf.Payor_line2 = payorConfs[1];
                if (payorLines.Count > 2)
                {
                    details.Payor_line3 = payorLines[2];
                    conf.Payor_line3 = payorConfs[2];
                }
            }

            // 4) Map remaining fields using Textract synonyms.
            var dateInfo = FindBySynonyms("date");
            if (dateInfo != null)
            {
                conf.Date = dateInfo.Confidence;
                if (DateTime.TryParse(dateInfo.Text, CultureInfo.InvariantCulture, DateTimeStyles.None, out var dt))
                    details.Date = dt.ToString("yyyy-MM-dd");
                else
                    details.Date = dateInfo.Text;
            }

            var checkNoInfo = FindBySynonyms("check_number");
            if (checkNoInfo != null)
            {
                details.Check_number = checkNoInfo.Text;
                conf.Check_number = checkNoInfo.Confidence;
            }

            var memoInfo = FindBySynonyms("memo");
            if (memoInfo != null)
            {
                details.Memo = memoInfo.Text;
                conf.Memo = memoInfo.Confidence;
            }

            var amountWordsInfo = FindBySynonyms("amount_in_words");
            if (amountWordsInfo != null)
            {
                details.Amount_in_words = amountWordsInfo.Text;
                conf.Amount_in_words = amountWordsInfo.Confidence;
            }

            // 5) Signature mapping.
            var sigInfo = FindBySynonyms("signature");
            if (sigInfo != null)
            {
                details.Signature = sigInfo.Text;
                conf.Signature = sigInfo.Confidence;
                details.Is_signed = "Yes";
            }

            var acctInfo = FindBySynonyms("account_number");
            if (acctInfo != null)
            {
                details.Account_number = acctInfo.Text;
                conf.Account_number = acctInfo.Confidence;
            }

            var routingInfo = FindBySynonyms("routing_number");
            if (routingInfo != null)
            {
                details.Routing_number = routingInfo.Text;
                conf.Routing_number = routingInfo.Confidence;
            }

            // 6) Amount in Numbers mapping.
            var numericCandidate = extracted.Values
                .Select(v => v.Text)
                .FirstOrDefault(t => !string.IsNullOrEmpty(t) && (t.StartsWith("$") || char.IsDigit(t.FirstOrDefault())));
            if (!string.IsNullOrWhiteSpace(numericCandidate))
            {
                conf.Amount_in_numbers = 0.95; // Placeholder confidence
                var cleaned = new string(numericCandidate.Where(c => char.IsDigit(c) || c == '.' || c == ',').ToArray());
                cleaned = cleaned.Replace(",", "");
                if (double.TryParse(cleaned, NumberStyles.Any, CultureInfo.InvariantCulture, out var parsedAmount))
                    details.Amount_in_numbers = parsedAmount;
            }
            if (details.Amount_in_numbers > 0 && !string.IsNullOrWhiteSpace(details.Amount_in_words))
                details.Is_amount_match = "Yes";

            return (details, conf);
        }
    }

    // Model classes
    public class CheckDetails
    {
        public string Payor_line1 { get; set; }
        public string Payor_line2 { get; set; }
        public string Payor_line3 { get; set; }
        public string Check_number { get; set; }
        public string Date { get; set; }
        public string Payee_name { get; set; }
        public double Amount_in_numbers { get; set; }
        public string Amount_in_words { get; set; }
        public string Is_amount_match { get; set; }
        public string Memo { get; set; }
        public string Is_signed { get; set; }
        public string Signature { get; set; }
        public string Routing_number { get; set; }
        public string Account_number { get; set; }
        public string Is_handwritten { get; set; }
    }

    public class CheckConfidence
    {
        public double Payor_line1 { get; set; }
        public double Payor_line2 { get; set; }
        public double Payor_line3 { get; set; }
        public double Check_number { get; set; }
        public double Date { get; set; }
        public double Payee_name { get; set; }
        public double Amount_in_numbers { get; set; }
        public double Amount_in_words { get; set; }
        public double Memo { get; set; }
        public double Signature { get; set; }
        public double Routing_number { get; set; }
        public double Account_number { get; set; }
    }

    public class CheckExtractionResult
    {
        public CheckDetails Check_details { get; set; }
        public CheckConfidence Confidence { get; set; }
        public List<ComprehendEntity> Comprehend_entities { get; set; }
        public string textractDocData { get; set; }
    }

    public class KeyValueInfo
    {
        public string Text { get; set; }
        public float Confidence { get; set; }
    }

    public class ComprehendEntity
    {
        public string Text { get; set; }
        public string Type { get; set; }
        public float Score { get; set; }
    }
}