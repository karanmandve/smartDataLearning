﻿using Amazon.S3;
using Amazon.S3.Model;
using Amazon.Textract.Model;
using Amazon.Textract;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Amazon.Runtime;
using Amazon;
using AWSServices.Services;
using AWSServices.Interface;

namespace AWSServices.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ImagesController : ControllerBase
    {
        private readonly IAmazonS3 _s3Client;
        private readonly string _bucketName = "karans3bucketdemo";
        private readonly IAmazonTextract _textractClient;
        private readonly ITextractService _textractService;
        private readonly Amazon.Comprehend.AmazonComprehendClient comprehendClient;

        public ImagesController(IAmazonS3 s3Client, IAmazonTextract textractClient, ITextractService textractService, IConfiguration configuration)
        {
            var credentials = new BasicAWSCredentials(configuration["AWS:AccessKey"], configuration["AWS:SecretKey"]);
            comprehendClient = new Amazon.Comprehend.AmazonComprehendClient(credentials, RegionEndpoint.APSouth1);
            _s3Client = s3Client;
            _textractClient = textractClient;
            _textractService = textractService;
        }


        [HttpPost("upload")]
        public async Task<IActionResult> UploadImage(IFormFile file)
        {
            if (file == null || file.Length == 0)
                return BadRequest("No file provided.");

            // Optionally generate a unique filename
            var fileName = $"{Guid.NewGuid()}_{Path.GetFileName(file.FileName)}";

            try
            {
                using var stream = file.OpenReadStream();
                var putRequest = new PutObjectRequest
                {
                    BucketName = _bucketName,
                    Key = fileName,
                    InputStream = stream,
                    ContentType = file.ContentType
                };

                var response = await _s3Client.PutObjectAsync(putRequest);

                if (response.HttpStatusCode == System.Net.HttpStatusCode.OK)
                    return Ok(new { FileName = fileName, Message = "Upload successful." });
                else
                    return StatusCode((int)response.HttpStatusCode, "Upload failed.");
            }
            catch (AmazonS3Exception s3Ex)
            {
                return StatusCode((int)s3Ex.StatusCode, s3Ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }


        [HttpGet("extract-raw-data")]
        public async Task<IActionResult> ExtractText([FromQuery] string fileName)
        {
            if (string.IsNullOrEmpty(fileName))
                return BadRequest("FileName is required.");

            try
            {
                var request = new DetectDocumentTextRequest
                {
                    Document = new Document
                    {
                        S3Object = new Amazon.Textract.Model.S3Object
                        {
                            Bucket = _bucketName,
                            Name = fileName
                        }
                    }
                };

                var response = await _textractClient.DetectDocumentTextAsync(request);
                string extractedText = "";
                foreach (var block in response.Blocks)
                {
                    if (block.BlockType == "LINE")
                    {
                        extractedText += block.Text + "\n";
                    }
                }
                var comprehendEntities = await AnalyzeEntitiesWithComprehend(extractedText);
                return Ok(new { FileName = fileName, ExtractedText = extractedText });
            }
            catch (AmazonTextractException textractEx)
            {
                return StatusCode((int)textractEx.StatusCode, textractEx.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        private async Task<List<ComprehendEntity>> AnalyzeEntitiesWithComprehend(string text)
        {
            // Build a Comprehend client using the same credentials & region as Textract


            var request = new Amazon.Comprehend.Model.DetectEntitiesRequest
            {
                Text = text,
                LanguageCode = "en"
            };

            var response = await comprehendClient.DetectEntitiesAsync(request);
            var entities = new List<ComprehendEntity>();

            foreach (var entity in response.Entities)
            {
                entities.Add(new ComprehendEntity
                {
                    Text = entity.Text,
                    Type = entity.Type,
                    Score = entity.Score
                });
            }

            return entities;
        }


        [HttpGet("extract-formated-data")]
        public async Task<IActionResult> ExtractForms(string fileName)
        {
            var bucketName = _bucketName;
            try
            {
                var jsonResult = await _textractService.ExtractFormsFromS3(bucketName, fileName);
                return Ok(jsonResult);
            }
            catch (Exception ex)
            {
                return BadRequest($"Error: {ex.Message}");
            }
        }





    }


}
