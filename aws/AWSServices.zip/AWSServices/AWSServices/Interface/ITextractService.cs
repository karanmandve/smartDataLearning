﻿namespace AWSServices.Interface
{
    public interface ITextractService
    {
        Task<string> ExtractFormsFromS3(string bucketName, string fileName);
    }
}
